package Client;

import FEAPP.*;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

import java.io.*;
import java.rmi.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
// same with student, just use interface and log the operations
public class AdvisorClient1{
    static FE ServerImp;

    public static void main(String[] args) {
        try{
            //int RMIPort;
            InputStreamReader is = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(is);
            String advisorID;//, portNum = "";
            System.out.println("Enter advisorID:");
            Scanner Id = new Scanner(System.in);
            advisorID = Id.nextLine();
            //InputStreamReader is = new InputStreamReader(System.in);
            //BufferedReader br = new BufferedReader(is);
            //advisorID = br.readLine();
            String department = advisorID.substring(0,4);
            String name = "FrontEnd";

//            if(department.equals("COMP"))
//                //portNum = "1234";
//                name = "DCRSCOMP";
//            else if (department.equals("SOEN"))
//                //portNum = "1235";
//                name = "DCRSSOEN";
//            else if (department.equals("INSE"))
//                //portNum = "1236";
//                name = "DCRSINSE";
//            else{
//                System.out.println("The advisorID is invalid");
//                System.exit(0);
//            }

            //RMIPort = Integer.parseInt(portNum);
            // create and initialize the ORB
            ORB orb = ORB.init(args, null);
            // get the root naming context
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            ServerImp = FEHelper.narrow(ncRef.resolve_str(name));

            //String registryURL = "rmi://localhost:"  + portNum + "/" + department;
            //System.setProperty("java.rmi.server.hostname",portNum);

            //ServerInterface h = (ServerInterface)Naming.lookup(registryURL);
            //System.out.println("Lookup completed ");

            if(ServerImp.Login(advisorID)){
                System.out.println("Log in successfully");
                String message = getDate() + " " + advisorID + "Log in successfully";
                Log(advisorID,message);
                while(true){
                    System.out.println("Please select following operations:");
                    System.out.println("1.add course");
                    System.out.println("2.remove course");
                    System.out.println("3.list course availability");
                    System.out.println("4.enrol course");
                    System.out.println("5.get class schedule");
                    System.out.println("6.drop course");
                    System.out.println("7.swap course");
                    System.out.println("8.exit");

                    Scanner scanner = new Scanner(System.in);
                    int number = Integer.parseInt(scanner.nextLine());
                    switch (number){
                        case 1:
                            System.out.println("Enter courseID");
                            Scanner scanner1 = new Scanner(System.in);
                            String courseID = scanner1.nextLine();
                            // check whether the advisor is the department's advisor
                            if(courseID.substring(0,4).equals(advisorID.substring(0,4))){
                                System.out.println("Enter semester");
                                Scanner scanner2 = new Scanner(System.in);
                                String semester = scanner2.nextLine();
                                System.out.println("Enter capacity");
                                Scanner scanner3 = new Scanner(System.in);
                                int capacity = scanner3.nextInt();
                                if(ServerImp.addCourse(advisorID, courseID,semester, (short) capacity) && capacity > 0){
                                    System.out.println("Add course successfully!");
                                    String result = getDate() + " " + advisorID + " add course " + courseID + " in " +
                                            semester + " semester successfully.";
                                    Log(advisorID, result);
                                }else{
                                    System.out.println("Add course failed!");
                                    String result = getDate() + " " + advisorID + " add course " + courseID + " in " +
                                            semester + " failed.";
                                    Log(advisorID,result);
                                }
                                break;
                            }else{
                                // no right
                                System.out.println("Add course failed!");
                                String result = getDate() + " " + advisorID + " add course " + courseID + " failed.";
                                Log(advisorID,result);
                                break;
                            }

                        case 2:
                            System.out.println("Enter courseID");
                            Scanner scanner2 = new Scanner(System.in);
                            String courseID2 = scanner2.nextLine();
                            // check wether the advisor is the department's advisor
                            if(courseID2.substring(0,4).equals(advisorID.substring(0,4))){
                                System.out.println("Enter semester");
                                Scanner scanner3 = new Scanner(System.in);
                                String semester2 = scanner3.nextLine();
                                if(ServerImp.removeCourse(advisorID, courseID2,semester2)){
                                    System.out.println("Remove course successfully!");
                                    String result = getDate() + " " + advisorID + " remove course " + courseID2 + " in " + semester2
                                            + " semester successfully.";
                                    Log(advisorID,result);
                                }else{
                                    System.out.println("Remove course failed!");
                                    String result = getDate() + " " + advisorID + " remove course " + courseID2 + " in " + semester2
                                            + " semester failed.";
                                    Log(advisorID,result);
                                }
                                break;
                            }else{
                                // no right
                                System.out.println("Remove course failed!");
                                String result = getDate() + " " + advisorID + " remove course " + courseID2 + " failed";
                                Log(advisorID,result);
                                break;
                            }
                        case 3:
                            System.out.println("Enter semester");
                            Scanner scanner4 = new Scanner(System.in);
                            String semester3 = scanner4.nextLine();
                            String result = ServerImp.listCourseAvailability(advisorID, semester3);
                            System.out.println(result);
                            String s = getDate() + " " + advisorID + " list course availability in " + semester3 + " : " + result;
                            Log(advisorID,s);
                            break;
                        case 4:
                            System.out.println("Enter studentID");
                            Scanner scanner55 = new Scanner(System.in);
                            String studentID = scanner55.nextLine();
                            if(checkAuthority(department,studentID)){
                                System.out.println("Enter courseID");
                                Scanner scanner6 = new Scanner(System.in);
                                String courseID4 = scanner6.nextLine();
                                System.out.println("Enter semester");
                                Scanner scanner7 = new Scanner(System.in);
                                String semester4 = scanner7.nextLine();
                                if(ServerImp.enrolCourse(advisorID, studentID,courseID4,semester4)){
                                    System.out.println("Enrol course successfully!");
                                    String s4 = getDate() + " " + advisorID + " enrol course " + courseID4 + " for "
                                            + studentID + " in " + semester4 + " semester successfully.";
                                    Log(advisorID,s4);
                                    break;
                                }else{
                                    System.out.println("Enrol course failed!");
                                    String s4 = getDate() + " " + advisorID + " enroll course " + courseID4 + " for "
                                            + studentID + " in " + semester4 + " semester failed.";
                                    Log(advisorID,s4);
                                    break;
                                }
                            }else{
                                System.out.println("You have no right to change student's data in other department!");
                                break;
                            }

                        case 5:
                            System.out.println("Enter studentID");
                            Scanner scanner8 = new Scanner(System.in);
                            String studentID5 = scanner8.nextLine();
                            if(checkAuthority(department,studentID5)){
                                String result5 = ServerImp.getClassSchedule(advisorID, studentID5);
                                System.out.println(result5);
                                String s5 = getDate() +  " get student: " + studentID5 + " all course schedule: " + result5;
                                Log(advisorID,s5);
                                break;
                            }else{
                                System.out.println("You have no right to get students' schedule in other departments!");
                                break;
                            }

                        case 6:
                            System.out.println("Enter studentID");
                            Scanner scanner9 = new Scanner(System.in);
                            String studentID6 = scanner9.nextLine();
                            if(checkAuthority(department,studentID6)){
                                System.out.println("Enter courseID");
                                Scanner scanner10 = new Scanner(System.in);
                                String courseID6 = scanner10.nextLine();
                                if(ServerImp.dropCourse(advisorID, studentID6,courseID6)){
                                    System.out.println("Drop course successfully!");
                                    String s6 = getDate() + " " + advisorID + " drop course " + courseID6 + " for "
                                            + studentID6 + "successfully.";
                                    Log(advisorID,s6);
                                    break;
                                }else{
                                    System.out.println("drop course failed!");
                                    String s6 = getDate() + " " + advisorID + " drop course " + courseID6 + " for "
                                            + studentID6 + " failed.";
                                    Log(advisorID,s6);
                                    break;
                                }
                            }else{
                                System.out.println("You have no right to drop students' courses in other departments");
                                break;
                            }

                        case 7:
                            System.out.println("Enter studentID");
                            Scanner scanner10 = new Scanner(System.in);
                            String studentID7 = scanner10.nextLine();
                            if (checkAuthority(department, studentID7)){
                                System.out.println("Enter old courseID");
                                Scanner scanner11 = new Scanner(System.in);
                                String oldCourseID = scanner11.nextLine();
                                System.out.println("Enter new courseID");
                                Scanner scanner12 = new Scanner(System.in);
                                String newCourseID = scanner12.nextLine();
                                if (ServerImp.swapCourse(advisorID, studentID7, newCourseID, oldCourseID)){
                                    System.out.println("swap course sucessfully!");
                                    String s7 = getDate() + " swap student: " + studentID7 + " course: " + oldCourseID + " to " + newCourseID;
                                    Log(advisorID, s7);
                                    break;
                                } else {
                                    System.out.println("swap course failed!");
                                    String s7 = getDate() + " swap student: " + studentID7 + " course: " + oldCourseID + " to " + newCourseID + "failed";
                                    Log(advisorID, s7);
                                    break;
                                }
                            }else {
                                System.out.println("You have no right to drop students' courses in other departments");
                                break;
                            }
                        case 8:
                            System.exit(0);

                            default:
                                break;
                    }
                }
            }else{
                System.out.println("Log in failed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void Log(String id, String message) throws Exception{
        String path = "/Users/chishuo/Desktop/project6231/FE/src/AdvisorLog/" + id + ".txt";
        FileWriter fileWriter = new FileWriter(path, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(message + "\n");
        bufferedWriter.close();
    }

    public static String getDate(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String dateForm = format.format(date);
        return dateForm;
    }

    // this method is to check wether the advisor can help the student or not
    public static boolean checkAuthority(String department,String studentID){
        String departmentS = studentID.substring(0,4);
        if(department.equals(departmentS))
            return true;
        else
            return false;
    }
}
