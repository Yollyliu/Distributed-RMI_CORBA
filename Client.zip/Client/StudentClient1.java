package Client;

import FEAPP.*;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
// TODO : DONE
public class StudentClient1{

    static FE ServerImp;
    public static void main(String[] args) {
        try{
            // RMIPort
            //int RMIPort;
            String studentID;
            //String portNum = "";
            System.out.println("Enter studentID:");
//            InputStreamReader is = new InputStreamReader(System.in);
//            BufferedReader br = new BufferedReader(is);
            Scanner Id = new Scanner(System.in);
            studentID = Id.nextLine();
            String department = studentID.substring(0,4);
            String name = "FrontEnd";

//            if(department.equals("COMP"))
//                //portNum = "1234";
//                name = "DCRSCOMP";
//            else if (department.equals("SOEN"))
//                //portNum = "1235";
//                name = "DCRSSOEN";
//            else if (department.equals("INSE"))
//                //portNum = "1236";
//                name = "DCRSINSE";
//            else{
//                System.out.println("Invalid StudentID");
//                System.exit(0);
//            }

            //RMIPort = Integer.parseInt(portNum);
            // set resigtryURL for localhost
            //String registryURL = "rmi://127.0.0.1:"  + portNum + "/" + department;
            // get the reference of the remote object
            //ServerInterface h = (ServerInterface) Naming.lookup(registryURL);
            //System.out.println("Lookup completed ");
            //boolean judge = h.studentLogin(studentID);

            ORB orb = ORB.init(args, null);
            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            ServerImp = FEHelper.narrow(ncRef.resolve_str(name));

            if(ServerImp.Login(studentID)){
                System.out.println("Log in successfully");
                // save operation
                String message = getDate() + " " + studentID + " log in successfully";
                Log(studentID,message);
                // listening
                while(true){
                    System.out.println("Please enter a number of following operations:");
                    System.out.println("1.enrol course");
                    System.out.println("2.get class schedule");
                    System.out.println("3.drop course");
                    System.out.println("4.swap courses");
                    System.out.println("5.exit");

                    Scanner scanner = new Scanner(System.in);
                    int selectOperation = Integer.parseInt(scanner.nextLine());
                    switch (selectOperation){
                        case 1:
                            System.out.println("Enter courseID");
                            Scanner scanner1 = new Scanner(System.in);
                            String courseID = scanner1.nextLine();
                            System.out.println("Enter semester");
                            Scanner scanner2 = new Scanner(System.in);
                            String semester = scanner2.nextLine();
                            if(ServerImp.enrolCourse(studentID, studentID,courseID,semester)){
                                System.out.println("Enroll course successfully!");
                                String s = getDate() + " " + " enrol course: "  + courseID + " in " + semester + "successfully";
                                Log(studentID,s);
                            }else{
                                System.out.println("enrol course failed!");
                                String s = getDate() + " enroll course: " + courseID + " in " + semester + " failed";
                                Log(studentID,s);
                            }
                            break;

                        case 2:
                            System.out.println(ServerImp.getClassSchedule(studentID, studentID));
                            String s2 = getDate() + " get class schedule.";
                            Log(studentID,s2);
                            break;

                        case 3:
                            System.out.println("Enter courseID");
                            Scanner scanner3 = new Scanner(System.in);
                            String courseID3 = scanner3.nextLine();
                            if(ServerImp.dropCourse(studentID, studentID,courseID3)){
                                System.out.println("Drop course successfully!");
                                String s3 = getDate() + " drop course: " + courseID3 + "successfully";
                                Log(studentID,s3);
                            }else{
                                System.out.println("drop course failed!");
                                String s3 = getDate() + " drop course: " + courseID3 + " failed ";
                                Log(studentID,s3);
                            }
                            break;

                        case 4:
                            System.out.println("Enter newCourseID");
                            Scanner scanner4 = new Scanner(System.in);
                            String newCourseID = scanner4.nextLine();
                            System.out.println("Enter oldCourseID");
                            Scanner scanner5 = new Scanner(System.in);
                            String oldCourseID = scanner5.nextLine();
                            if(ServerImp.swapCourse(studentID, studentID, newCourseID, oldCourseID)){
                                System.out.println("Swap course successfully!");
                                String s4 = getDate() + " swap course: " + oldCourseID + " to " + newCourseID + "successfully";
                                Log(studentID,s4);
                            }else{
                                System.out.println("Swap course failed!");
                                String s4 = getDate() + " swap course: " + oldCourseID + " to " + newCourseID + " failed ";
                                Log(studentID,s4);
                            }
                            break;
                        case 5:
                            System.exit(0);

                        default:
                            break;
                    }
                }
            }else{
                System.out.println("Log in failed!");
            }
        }catch(Exception e){
            System.out.println("Exception in StudentClient1: " + e);
            System.out.println(e.getCause());
            System.out.println(e.getLocalizedMessage());
            System.out.println(e.getStackTrace());
            e.printStackTrace();
        }
    }

    public static void Log(String id, String message) throws Exception{
        String path = "/Users/chishuo/Desktop/project6231/FE/src/StudentLog/" + id + ".txt";
        FileWriter fileWriter = new FileWriter(path, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(message + "\n");
        bufferedWriter.close();
    }

    public static String getDate(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String dateForm = format.format(date);
        return dateForm;
    }

}

