package src.replicaManager;

public class ReplicaManager {
	
	static RMImpl rm1 = new RMImpl();
	
	public static void main(String[] args) {
		System.setProperty("java.net.preferIPv4Stack", "true");
		
		Runnable receivefromReplica = () -> {
			try{
			//port for receive
			rm1.UDPRequestFromReplica(7000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Thread replicatread = new Thread(receivefromReplica);
		replicatread.start();
		
		//Start replica.
		Runnable restart = () -> {
			try{
			//port for receive
			rm1.restart(0);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Thread starttread = new Thread(restart);
		starttread.start();
		
		Runnable receive = () -> {
			try{
			//port for receive
			rm1.UDPRequestFromOthers();
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Thread receivetread = new Thread(receive);
		receivetread.start();
		
		//Receive UDP request from Sequencer.
		rm1.UDPRequestFromSequencer();
	}
}
