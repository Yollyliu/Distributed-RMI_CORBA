package src.replicaManager;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import src.implement.Replica1COMPServer;
import src.implement.Replica1INSEServer;
import src.implement.Replica1SOENServer;
import src.implement.Replica2COMPServer;
import src.implement.Replica2INSEServer;
import src.implement.Replica2SOENServer;


public class RMImpl extends Thread{
	
	//Records for all the request
	public static List<String> requestList = new ArrayList<>();
	
	//Records for to do list
	public static List<String> toDoList = new ArrayList<>();
	
	public static int totalNbr = 1;
	
	public static String FEID = "";
	
	public static int softwareFailureCount = 0;
	
	public static String replicaName = "Replica4";
	
	
	//Receive request from Sequencer and forward to replica
	public void UDPRequestFromSequencer() {
		MulticastSocket aSocket = null;
		try {

			aSocket = new MulticastSocket(1314);
			aSocket.joinGroup(InetAddress.getByName("230.1.1.5"));

			System.out.println("Replica Manager Started............");

			while (true) {
				byte[] buffer = new byte[1000];
				//Receive message from sequencer.
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				
				//Get information from request.
				String strtemp = new String(request.getData());
				String str = strtemp.replaceAll("/","").trim();
				byte[] fff = str.getBytes();
				String arg[] = str.split("\\_");
				
				System.out.println("Receive from Sequencer:"+str);
				/* 
				 * arg[2] = seqNbr
				 * arg[3] = department
				 * if the message is the right one should be executed immediately.
				*/
				if(totalNbr == Integer.parseInt(arg[2])) {
					//Forward message to replica.
					InetAddress host = InetAddress.getByName("localhost");
					
					
					int port1 = router1(arg[3]);
					
					int port2 = router2(arg[3]);
					
					DatagramPacket forwardMessage1 = new DatagramPacket(fff, fff.length, host, port1);
					aSocket.send(forwardMessage1);
					
					DatagramPacket forwardMessage2 = new DatagramPacket(fff, fff.length, host, port2);
					aSocket.send(forwardMessage2);
					
					totalNbr = totalNbr + 1;
					//Record request into finished list.
					requestList.add(str);
					for (Iterator<String> iterator = requestList.iterator(); iterator.hasNext();) {
							String message = iterator.next();
							System.out.println("requestlist: "+ message);
					}
				}
				
				
				/*
				 * To check if the request in the check list is the right request.
				 */
				if(toDoList.isEmpty() == false) {
					//check the todo list.
					for (Iterator<String> iterator = toDoList.iterator(); iterator.hasNext();) {
						String message = iterator.next();
						byte[] result = message.getBytes();
						String a[] = message.split("\\_");
						
						if(totalNbr == Integer.parseInt(a[2])) {
							InetAddress host = InetAddress.getByName("localhost");
							System.out.println("department-------"+ arg[3]);
							int port1 = router1(arg[3]);
							int port2 = router2(arg[3]);
							
							System.out.println("rounter number in------ :"+port1);
							System.out.println("rounter number in------ :"+port2);
							
							DatagramPacket toDoMessage1 = new DatagramPacket(result, result.length, host, port1);
							aSocket.send(toDoMessage1);
							
							DatagramPacket toDoMessage2 = new DatagramPacket(result, result.length, host, port2);
							aSocket.send(toDoMessage2);
							
							//Remove the request from to do list.
							iterator.remove();
							//Add totalNbr for next request.
							totalNbr = totalNbr + 1;
							//Record request into finished list.
							requestList.add(message);
						}
					}
				}
				
				//Add the request into to do list.
				if(totalNbr < Integer.parseInt(arg[2])) {
					toDoList.add(str);
					
					//Ask the sequencer for request from sequencer number = tatalNbr.
					String a = String.valueOf(totalNbr);
					byte[] result = a.getBytes();
					DatagramPacket askMessage = new DatagramPacket(result, result.length, request.getAddress(), 2001);
					aSocket.send(askMessage);
				}
			}
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
	}
	
	//Be the IP Router
	public int router1(String UserID) {
		int port=0;
		if(UserID.contains("COMP")) {
			port=1111;
		}
		if(UserID.contains("INSE")) {
			port= 1112;
		}
		if(UserID.contains("SOEN")) {
			port= 1113;
		}
		return port;
	}
	
	//Be the IP Router2
	public int router2(String UserID) {
		int port=0;
		if(UserID.contains("COMP")) {
			port=1211;
		}
		if(UserID.contains("INSE")) {
			port= 1212;
		}
		if(UserID.contains("SOEN")) {
			port= 1213;
		}
		return port;
	}
    
	public void UDPRequestFromReplica(int port) throws NumberFormatException, Exception {
		
		DatagramSocket aSocket = null;
		
		try {

			aSocket = new DatagramSocket(port);


			System.out.println("Replica forwarder Started............");
			while (true) {
				//Receive message from sequencer.
				byte[] buffer = new byte[1000];
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				
				//Get information from request.
				String str = new String(request.getData());
				System.out.println("ready to send to fe"+str+"."+str.length());

				String arg[] = str.split("\\_");
				
				
				
				String fb = arg[2] + "_" +replicaName+"_"+arg[3]+ "_" + arg[4].trim();
				System.out.println(fb);
				byte[] result = fb.getBytes();
				
				//arg[0] = ip arg[1] = port 
				InetAddress host = InetAddress.getByName(arg[0]);
				DatagramPacket rMessage = new DatagramPacket(result, result.length, host, Integer.parseInt(arg[1]));
				aSocket.send(rMessage);
				System.out.println("result: "+fb);
				System.out.println("host: "+host);

				System.out.println("port: "+Integer.parseInt(arg[1]));
				
				System.out.println("send to fe success.");
			//	totalNbr = totalNbr + 1;
			}
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
	}
	
	//
	public void UDPRequestFromOthers() throws Exception {		
		
		DatagramSocket aSocket = null;
		try {
			aSocket = new DatagramSocket(2020);

			while (true) {
				byte[] buffer = new byte[1000];
				//Receive message from sequencer.
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				
				//Get information from request.
				String str = new String(request.getData());				
				System.out.println(str);
				
				
				String arg[] = str.split("\\_");
				arg[1] = arg[1].trim();
				
				//Count for software failure and replace it.
				if(arg[1].equals("SoftwareFailure")){ 
					Runnable receive = () -> {
						try{
							//softwareFailureHandler
							softwareFailureHandler(arg[0]);
						} catch (Exception e) {
						e.printStackTrace();
						}
					};
				
				Thread receivetread = new Thread(receive);
				receivetread.start();
				}
				
				//Send check message to the error RM with check
				if(arg[1].equals("Crash")){
					if(replicaName.equals(arg[0])) {
						Runnable receive = () -> {
							try{
								//port for receive
								crash(arg[0]);
							} catch (Exception e) {
							e.printStackTrace();
							}
						};
					
					Thread receivetread = new Thread(receive);
					receivetread.start();
					}
				}
				
				//check the replica. If it has crashed, restart it.
				if(arg[1].equals("restart")) {
					Runnable receive = () -> {
						try{
						//run restart
							restart(1);
						} catch (Exception e) {
							e.printStackTrace();
						}
					};
					
					Thread receivetread = new Thread(receive);
					receivetread.start();
				}
			}
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
	}
	
	public void crash(String name) throws Exception {

		DatagramSocket aSocket = new DatagramSocket(1911);
		try {

				String alive = "hello";
				byte[] result = alive.getBytes();

				System.out.println("localhost");
				
				InetAddress ip = InetAddress.getByName("localhost");
				DatagramPacket aliveMessage = new DatagramPacket(result, result.length, ip, 9999);
				aSocket.send(aliveMessage);

				//calculate interval
				while(true) {
					byte[] buffer = new byte[1000];
	
					aSocket.setSoTimeout(3000);

					DatagramPacket keepAlive = new DatagramPacket(buffer, buffer.length);
					aSocket.receive(keepAlive);
				}
						
			}catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			
			if (aSocket != null)
				aSocket.close();
				DatagramSocket bSocket = new DatagramSocket(1911);
	
				String restart = name + "_restart";
				byte[] rb = restart.getBytes();
				InetAddress ip = InetAddress.getByName("localhost");
				DatagramPacket restartMessage = new DatagramPacket(rb, rb.length, ip, 2020);
				System.out.println("this is before restart messege send");
				bSocket.send(restartMessage);
				System.out.println("this is after restart messege send");
				bSocket.close();
				//return;
				//}
			
		}
	}
	
	
	public void softwareFailureHandler(String rmid) throws Exception {
		
		DatagramSocket aSocket = new DatagramSocket();
		try {
			//write log.
			if(replicaName.equals(rmid)) {
				softwareFailureCount = softwareFailureCount + 1;
				if(softwareFailureCount >= 3) {
					//replace the replica with a right one.
					String shutdown = "1_2_3_4_5_shutdown_";
					byte[] result = shutdown.getBytes();
					InetAddress host = InetAddress.getByName("localhost");
					DatagramPacket askMessage = new DatagramPacket(result, shutdown.length(), host, 1111);
					aSocket.send(askMessage);
					askMessage = new DatagramPacket(result, result.length, host, 1112);
					aSocket.send(askMessage);
					askMessage = new DatagramPacket(result, result.length, host, 1113);
					aSocket.send(askMessage);
					
					Thread.sleep(15000);
					//restart new replica
					restart(2);
					}
				
				} else {
					softwareFailureCount = 0;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
		//if not, whatever.
		
	}
	
	//Start replica and crash handler
	public void restart(int nbr) throws InterruptedException, IOException {
		DatagramSocket sSocket = new DatagramSocket();
		String message;
		
		//Shut down
		String shutdown = "1_2_3_4_5_shutdown_";
		byte[] result = shutdown.getBytes();
		InetAddress host = InetAddress.getByName("localhost");
		DatagramPacket askMessage = new DatagramPacket(result, shutdown.length(), host, 1111);
		sSocket.send(askMessage);
		askMessage = new DatagramPacket(result, result.length, host, 1112);
		sSocket.send(askMessage);
		askMessage = new DatagramPacket(result, result.length, host, 1113);
		sSocket.send(askMessage);
		
		
		//Thread.sleep(15000);
		
		System.out.println("restart here");
		
		
		Runnable comp = () -> {
			try{
			//port for receive
			if(nbr == 0) {
				Replica1COMPServer.main(null);
			} else {
				Replica2COMPServer.main(null);
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Runnable soen = () -> {
			try{
			//port for receive
				if(nbr == 0) {
					Replica1SOENServer.main(null);
				}  else {
					Replica2SOENServer.main(null);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Runnable inse = () -> {
			try{
			//port for receive
			if(nbr == 0) {
				Replica1INSEServer.main(null);
			} else {
				Replica2INSEServer.main(null);
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Thread comptread = new Thread(comp);
		comptread.start();
		
		Thread soentread = new Thread(soen);
		soentread.start();
		
		Thread insetread = new Thread(inse);
		insetread.start();
		
		Thread.sleep(5000);
		
		try {
			for (Iterator<String> iterator = requestList.iterator(); iterator.hasNext();) {
				System.out.println("run back up");
					message = iterator.next();
					System.out.println(message);
					result = message.getBytes();
					String arg[] = message.split("\\_");
				
					//Get replica address.
					host = InetAddress.getByName("localhost");
					
					DatagramPacket restartMessage1 = new DatagramPacket(result, result.length, host, router1(arg[3]));
					DatagramPacket restartMessage2 = new DatagramPacket(result, result.length, host, router2(arg[3]));
					
					
					//Recovery
					
					sSocket.send(restartMessage1);
					sSocket.send(restartMessage2);
			}
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (sSocket != null)
				sSocket.close();
		}
	}
}
