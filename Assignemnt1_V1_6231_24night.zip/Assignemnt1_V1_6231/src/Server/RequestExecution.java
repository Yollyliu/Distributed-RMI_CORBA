package Server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class RequestExecution extends Thread{
	
	public Thread t;
	public CRImpl server;
	public DatagramSocket serversocket;
	public InetAddress address;
	public int clientport;
	String message;
	
	public RequestExecution(CRImpl server,DatagramSocket serversocket,InetAddress address,int clientport,String message) {
		super();
		this.address = address;
		this.message = message;
		this.server = server;
		this.clientport = clientport;
		this.serversocket = serversocket;
	}
	
	public void start(){
		if(t == null){
			t = new Thread(this);
			t.start();
		}
	}
	
	public void run(){
		String result = " ";
//		System.out.println("the message is "+message);
		if(message.startsWith("listCourseA")){
			
			result = UDPlistCourseA(message);
//			System.out.println("The result of this message is :"+ result);
		}
		else if(message.startsWith("enrollCourse")){
			result = UDPenrollCourse(message);
		}
		else if(message.startsWith("dropCourse")){
			result = UDPdropCourse(message);
		}else if(message.startsWith("removeCourse")) {
			result=UDPremoveCourse(message);
		}
		byte []buffer = result.getBytes();
		DatagramPacket reply = new DatagramPacket(buffer, buffer.length,address,clientport);
		try {
			serversocket.send(reply);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String UDPlistCourseA(String message){
		String data = message.substring(message.indexOf("(") + 1,message.length() - 1);
		String result = server.listCourseALocal(data);
//		System.out.println("Result in RequestExecution "+ result );
		return result;   //right at this time
	}
	
	public String UDPenrollCourse(String message){
		String arguments = message.substring(message.indexOf("(") + 1,message.length() - 1);
		String arg[] = arguments.split(",");
		String studentID = arg[0];
		String courseID = arg[1];
		String term = arg[2];
		String result = server.incertEnroll(studentID,courseID,term);
		return result;
	}
	
	public String UDPdropCourse(String message){
		String arguments = message.substring(message.indexOf("(") + 1,message.length() - 1);
		String arg[] = arguments.split(",");
		String stdID = arg[0];
		String courseID = arg[1];
		String term=arg[2];
		String result=server.dropCourseLocal(stdID, courseID,term);
		return result;
	}
	
	public String UDPremoveCourse(String message){
		String arguments = message.substring(message.indexOf("(") + 1,message.length() - 1);
		String arg[] = arguments.split(",");
		String stdID = arg[0];
		String cID = arg[1];
		String result=server.dropForStudent(stdID, cID);
		return result;
	}
	

}
