package Server;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService(endpointInterface = "Server.ServerInterface",
			serviceName = "serverService",
			portName = "serverport",
			targetNamespace = "http://server")



public class CRImpl implements ServerInterface {  //one local server function inplement

	class StdClient {
		String studentID = "";
		int[] takeCourse = { 0, 0, 0 }; // 0:fall 1: winter 2:summer
		HashMap<String, String> registedCourse=new HashMap<>(); // key:courseID value: Term

	}

	class Course {
		public String courseID = "";
		public int capacity = 100;
		public int stdNumb = 0; // enrolled students number
		public LinkedList<String> enrolledStd = new LinkedList<>();
		public String roomID = "";
		public String prof = "";
		public boolean avaialbe = true;
	}


	class AdvClient {
		String advisorID = "";

	}

	LinkedList<StdClient> stdClients = new LinkedList<>();
	LinkedList<AdvClient> advClients = new LinkedList<>();


	HashMap<String, HashMap<String, Course>> courseMap = new HashMap<String, HashMap<String, Course>>();

	public String Department = "";

	private Lock lock = new ReentrantLock();
	
	@Override
	public int sumoftwo(int x,int y){
		return x + y;
	}



	public static void Log(String Id, String psw) throws Exception{

		String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/ServerLog/"+ Id+".txt";
		FileWriter fileWriter = new FileWriter(path,true);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		bufferedWriter.write(psw + "\n");
		bufferedWriter.close();
	}

	public String getData() {
		Date date = new Date();
		long times = date.getTime();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String timeString = format.format(date);
		return timeString;
	}

	public void StartServer(String Depart) {
		Department = Depart;
		try {
			Log(Department, getData() + " Server for " + Depart + " started");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean advLogin(String advID)  {

		Boolean login = false;

		for (int i = 0; i < advClients.size(); i++) {
			if (advClients.get(i).advisorID.equals(advID)) {
				login = true;
				break;
			}
		}

		if (!login) {
			AdvClient advisor = new AdvClient();
			advisor.advisorID = advID;
			advClients.add(advisor);
		}

		System.out.println("Advisor: " + advID + " login");

		try {
			Log(Department, getData()+" Advisor: " + advID + " login.");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}

	@Override
	public boolean stdLogin(String stdID)  {

		Boolean exist = false;

		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				exist = true;
				break;
			}
		}

		if (!exist) {
			StdClient student = new StdClient();
			student.studentID = stdID;
			stdClients.add(student);
		}
		System.out.println("Student: " + stdID + " Login");

		try {
			Log(Department, getData()+ " Student: " + stdID + "Login");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}


	@Override
	public boolean addCourse(String courseID, String term, String advID, String capacity)
			 {

		Boolean create = false;
		String courseDept=courseID.substring(0, 4);
		String advDept=advID.substring(0, 4);
		if(courseDept.equals(advDept)) {
		
		if(addCourseLocal(courseID, term, advID, capacity)) {
			create=true;
			try {
				System.out.println( "advisor " + advID + " add course " + courseID + " in " + term + " term.");
				Log(Department, getData()+ " advisor " + advID + " add course " + courseID + " in " + term + " term.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}
		}
		if(!create) {
			try {
				System.out.println(" advisor " + advID + " failed to add course " + courseID + " in " + term + " term.");
				Log(Department, " advisor " + advID + " failed to add course " + courseID + " in " + term + " term.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}
		return create;
	}

	public boolean addCourseLocal(String courseID, String term, String advID, String capacity) {
		
//		if(capacity.equals("0")) {
//			
//			return false;
//			
//		}else {
		
		try {
			lock.lock();
		
			if (courseMap.containsKey(term)) {               //all course are in courseMap
				if (courseMap.get(term).containsKey(courseID)) {      //this course already in the courseMap
					try {
						Log(Department, getData()+ " advisor " + advID + "fail to add course " + courseID 
								+ " in " + term + " term because this course already exist in this term.");
					} catch (Exception e) {
						e.printStackTrace();
					}
					
//					System.out.println("The course " + courseID + " already exists in " + term + " term");
					return false;
				} else {                 //this course not exist in the courseMap
					Course curCourse = new Course();
					curCourse.courseID = courseID;
					curCourse.capacity=Integer.valueOf(capacity);
					if(curCourse.capacity==0) {
						curCourse.avaialbe=false;
					}
					

					courseMap.get(term).put(courseID, curCourse);   // this is the problem
//					System.out.println("The advisor +"+ advID+ "add this course "+ courseID+" successfull, this message is from CRImpl 1.");

					// courseMap.get(term).put(courseID, courseDetail);
					try {
						Log(Department, getData()+ " advisor " + advID + " add course " + courseID + " in " + term + " term.");
					} catch (Exception e) {
						e.printStackTrace();
					}
					return true;

				}
			} else {   //courseMap didnot have this term
				HashMap<String, Course> courseInf = new HashMap<String, Course>();
				Course curCourse = new Course();
				curCourse.courseID = courseID;
				curCourse.capacity=Integer.valueOf(capacity);
				if(curCourse.capacity==0) {
					curCourse.avaialbe=false;
				}

				courseInf.put(courseID, curCourse);
				courseMap.put(term, courseInf);
//				System.out.println("The advisor +"+ advID+ "add this course "+ courseID+" successfull, this message is from CRImpl 2.");
			return true;
			
		}
		}finally {
			lock.unlock();
		}
	//	}
		
		
	}
//	
//	
	

	@Override
	public boolean removeCourse(String courseID, String term, String advID)  {

		boolean remove = false;
		int number = 0;
		if(courseID.substring(0, 4).equals(advID.substring(0, 4))) {
		try {
				lock.lock();
		if (courseMap.containsKey(term)) {
			if (courseMap.get(term).containsKey(courseID)) {
				Course curCourse = new Course();
				curCourse = courseMap.get(term).get(courseID);
				number = curCourse.stdNumb;    // if students enroll in this course

				if (number != 0) {
					for (int i = 0; i < curCourse.enrolledStd.size(); i++) {
						String curResutl="";
						
						String curStdDepart=curCourse.enrolledStd.get(i).substring(0, 4);
						System.out.println("The student "+ curCourse.enrolledStd.get(i)+" enroll in this course. From removeCourse function.");
						if(curStdDepart.equals(Department)) {
						
						
						curResutl=dropForStudent(curCourse.enrolledStd.get(i), courseID);      // call the dropCourse function to delete student enroll in this course
						}
						else {
							System.out.println("we will connect the local server.");
							String curStd=curCourse.enrolledStd.get(i);
							
							String command = "removeCourse(" + curStd + "," + courseID +  ")";
							try {
								if (curStdDepart.equals("COMP")) {
									System.out.println("we will connect COMP server");
									curResutl = UDPRequest.UDPremoveCourse(command, 2111); // comp
									System.out.println("The result of dropForStudent"+curResutl);

								} else if (curStdDepart.equals("INSE")) {
									System.out.println("we will connect INSE server");
									curResutl = UDPRequest.UDPremoveCourse(command, 3222); // INSE
									System.out.println("The result of dropForStudent"+curResutl);
								} else {
									System.out.println("we will connect SOEN server");
									curResutl = UDPRequest.UDPremoveCourse(command, 4333); // SOEN
									System.out.println("The result of dropForStudent"+curResutl);

								}

							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}

				}
				courseMap.get(term).remove(courseID); // remove that record
				remove = true;
//				System.out.println("The course " + courseID + " is removed in " + term + " term by advisor " + advID);
				try {
					System.out.println(" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
					Log(Department,
							getData()+" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
			
		}
		}finally {
			lock.unlock();
		}
		}

		
		
			if(!remove) {
				try {
					System.out.println(" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");
				Log(Department, getData()+" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			}
		
		return remove;

	}
	
	
	

	

	public String listCourseALocal(String term) {   //this work well 

//		System.out.println("Searching for Local Department Course Availability: "+Department);
		String result = " ";
		String curResult="";

		try {
			lock.lock();
			if (courseMap.containsKey(term)) {
				HashMap<String, Course> curTermMap = new HashMap<>();
				curTermMap = courseMap.get(term);
				Iterator iterator = curTermMap.keySet().iterator();
				while (iterator.hasNext()) {
					int restNum = 0;
					Course curCourse = new Course();
					curCourse = curTermMap.get(iterator.next());
					restNum = curCourse.capacity - curCourse.stdNumb;
					curResult =curResult+ curCourse.courseID + " " + Integer.toString(restNum) + ", ";
				}
			}
		}finally {
			lock.unlock();
		}
		System.out.println("Done, the result of Course Availability in "+Department+" department is "+ curResult);

		return result=curResult;
	}

	@Override
	public String listCourseA(String advID, String term)  {

		String result = term + " - " + listCourseALocal(term);
		String depart = advID.substring(0, 4);
		String command = "listCourseA(" + term + ")";             //2018.0930 changed here 


		try {
			if (depart.equals("COMP")) {
				int serverport1 = 3222; // INSE
				int serverport2 = 4333; // SOEN
				
				System.out.println("Searching for INSE department course availbility");
				String result1=UDPRequest.listCourseA(command, serverport1);
//				System.out.println(result1);
			
				
				System.out.println("Searching for SOEN department course availbility");
				String result2=UDPRequest.listCourseA(command, serverport2);
//				System.out.println(result2);
				result = result + " " + result1+" "+result2;
				
			} else if (depart.equals("INSE")) {
				int serverport3 = 2111; // COMP
				int serverport4 = 4333; // SOEN
				System.out.println("Searching for COMP department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport3));
				String result3 =  UDPRequest.listCourseA(command, serverport3);
				
				System.out.println("Searching for SOEN department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport4));
				String result4 = UDPRequest.listCourseA(command, serverport4);
				result =result + " "+ result3 +" "+result4;
				
			} else {
				int serverport5 = 2111; // COMP
				int serverport6 = 3222; // INSE
				
				System.out.println("Searching for COMP department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport5));
				String result5 = UDPRequest.listCourseA(command, serverport5);
				
				System.out.println("Searching for INSE department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport6));
				String result6 = UDPRequest.listCourseA(command, serverport6);
				
				result =result + " "+ result5 +" "+result6;
			}

		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Log(Department, getData() + " Advisor ID " + advID + " check course aviability on " + term
					+" the result is"+ result);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public String enrollCourse(String stdID, String courseID, String term)  {
		//if the student can enroll an other Department course, then use enrolCourseLocal
		String stdDepart=stdID.substring(0, 4);
		String courseDepart=courseID.substring(0,4);
		String command = "enrollCourse(" + stdID + "," + courseID + "," + term + ")" ;
		int otherDpNumb=0;
		
		String result=" ";

		String curTerm=term.toLowerCase();
		boolean exist=false;
		
		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(term)) {
				exist=true;
			}
		}
		if (!exist) {
			StdClient newStd=new StdClient();
			newStd.studentID=stdID;
			stdClients.add(newStd);
		}
		
		System.out.println("The size of stdClients : "+stdClients.size()+" this information from enrollCourse");
		for(int i=0;i<stdClients.size();i++) {
//			System.out.println("hello, we are going to find ");
//			System.out.println("The list of stdClients is :"+stdClients.get(i).studentID);
//			System.out.println("The student id is"+stdID);
			if(stdClients.get(i).studentID.equals(stdID) ){     //when student login, it will have record there
//			System.out.println("hello,  find student id");
			
			if(stdClients.get(i).registedCourse.containsKey(courseID)) {
				System.out.println("Student already in this couse.");
			}else {
	
//				if(!stdClients.get(i).registedCourse.containsKey(courseID)){
//					System.out.println("hello, the student is not registered this class");
			
				if((stdClients.get(i).takeCourse[0]<=2 && curTerm.equals("fall"))       //if that term is less or equal to 2 course
					|| (stdClients.get(i).takeCourse[1]<=2 && curTerm.equals("winter"))||
					(stdClients.get(i).takeCourse[2]<=2 && curTerm.equals("summer"))){
					
//					System.out.println("hello, find the student is not enroll in two course in one term ");
								
					try {
						String curResult=" ";
						if(stdDepart.toLowerCase().equals(courseDepart.toLowerCase())) {
//							System.out.println("The student want to enroll a course in his own department.");
							curResult = incertEnroll(stdID, courseID, curTerm);   // if the student is own department student
//							System.out.println("The result of this student is "+ result+" this message is from enrollCourse");
						}else {
							HashMap<String, String> curEnrolledMap=new HashMap<>();  //if the student is enrolled in other department 
							curEnrolledMap=stdClients.get(i).registedCourse;
							Iterator< String> iterator=curEnrolledMap.keySet().iterator();

							while(iterator.hasNext()) {     
								String key = iterator.next();
								String cur=key.substring(0, 4);          //cur is the courseID's department
								if(!cur.equals(stdDepart)) {
									otherDpNumb++;
								}
							}
							System.out.println(stdID+" enrolled in "+otherDpNumb+" course in other department");
							
							if( otherDpNumb<=1) {
								
								
								if(courseDepart.equals("COMP")) {
									System.out.println("We are going to use COMP server");
									curResult = UDPRequest.UDPenrollCourse(command, 2111);  //comp
								}
								else if(courseDepart.equals("INSE")) {
									System.out.println("We are going to use INSE server");
									curResult= UDPRequest.UDPenrollCourse(command, 3222);    //INSE
								}
								else {
									System.out.println("We are going to use COMP server");
									curResult= UDPRequest.UDPenrollCourse(command, 4333);     //SOEN
								}
//								System.out.println("The current state is "+ curResult);
	                         }							         
						}
						if(!curResult.equals(" ")) {
							result=enrollCourseLocol(stdID, courseID, curTerm);
//							if(!result.equals(" ")) {
//								return true;
//							}
							
						}
						
					} catch (Exception e) {
						
					
				}
			
			}
			}
			break;
			}
			
		}	

		if(result.equals(" ")){
			result="fail";
			System.out.println("Student " + stdID + " failed to enrolled in "+ courseID+ ". " );
			try {
				Log(Department, getData() + " Student " + stdID + " failed to enrolled in "+ courseID+ ". " );
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}else {
			result="success";
			System.out.println("Student "+ stdID+" is enroll in this class "+courseID);

			try {
				Log(Department, getData()+" Student "+ stdID+" successfully enrolled in this class "+courseID);
			}catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}

	}

	public String enrollCourseLocol(String stdID, String courseID, String term) {
		
		String result=" ";

//			System.out.println("WE are changing the student information");
		try {
			lock.lock();
				for (int i = 0; i < stdClients.size(); i++) {
					if (stdClients.get(i).studentID.equals(stdID)) {
						System.out.println("we are add course number in related term. This message is from enrollCourseLocal");
						
						stdClients.get(i).registedCourse.put(courseID, term);     // put course in that semster
						
						if (term.equals("fall")) {
							stdClients.get(i).takeCourse[0]++;    //term course add 1
//							System.out.println("fall add 1,Done. This message is from enrollCourseLocal");
						} else if (term.equals("winter")) {
							stdClients.get(i).takeCourse[1]++;
						} else {
							stdClients.get(i).takeCourse[2]++;
						}
						
						result="success";
						System.out.println("The result is "+ result+ " This message is from enrollCourseLocal");
//						break;

						
						return result;

					}
				}
			}finally {
				lock.unlock();
			}
//			System.out.println("The result of the enrollCourseLoal is"+ result+" This message from enrollCourseLocal");
			return result;
			
		}

		
		

	
	public String incertEnroll(String stdID, String courseID, String term){     //need to return a string for enroll result
		
		System.out.println("We are at the incertEnroll function and want to put the student in it.");
		String result=" ";
		try {
			lock.lock();
			System.out.println("Trying to enroll in incertEnroll "+ Department);
			if (courseMap.containsKey(term)) {       //which departemt courseMap
				if (courseMap.get(term).containsKey(courseID)) {    //so it was all wrong when use iterator					
					if(courseMap.get(term).get(courseID).avaialbe) {
//						System.out.println("This course is available. ");
						courseMap.get(term).get(courseID).enrolledStd.add(stdID);
						courseMap.get(term).get(courseID).stdNumb++;
						if(courseMap.get(term).get(courseID).stdNumb==courseMap.get(term).get(courseID).capacity) {
							courseMap.get(term).get(courseID).avaialbe=false;
						}
						result="success";
					}
				}
			}
		}finally {
			lock.unlock();
		}
		return result;
	}
	

	@Override
	public boolean dropCourse(String stdID, String courseID)  {

		String stdDepart = stdID.substring(0, 4);
		String courseDepart = courseID.substring(0, 4);
		String result=" ";
		
		String term=dropForStudent(stdID, courseID);
		if(term.equals(" ")) {
			return false;
		}else {
		

		String command = "dropCourse(" + stdID + "," + courseID + ","+term+ ")";
		if (stdDepart.equals(courseDepart)) {

			result= dropCourseLocal(stdID, courseID,term);
		} else {
			try {
				if (courseDepart.equals("COMP")) {
					result = UDPRequest.UDPdropCourse(command, 2111); // comp
				} else if (courseDepart.equals("INSE")) {
					result = UDPRequest.UDPdropCourse(command, 3222); // INSE
				} else {
					result = UDPRequest.UDPdropCourse(command, 4333); // SOEN
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

//			return true;
		}
		if(result.equals(" ")){
			System.out.println("studentClient " + stdID + " failed to drop "+ courseID+ " course." );
			try {
				Log(Department, getData() + "Student " + stdID + " failed to drop "+ courseID+ " course." );
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
		}else {

			
			System.out.println(result);
			try {
				Log(Department, getData() + " Student " + stdID + " success to drop "+ courseID+ " course.");
			}catch (Exception e) {
				e.printStackTrace();
			}
			return true;
		}
	
	}

	public String dropCourseLocal(String stdID, String courseID, String term) {

		String result=" ";
//		String term1=dropForStudent(stdID, courseID);
//		if(term1.equals(" ")) {
//			return term;
//		}
		try {
			lock.lock();
			
			courseMap.get(term).get(courseID).stdNumb--;
			int index=courseMap.get(term).get(courseID).enrolledStd.indexOf(stdID);
			courseMap.get(term).get(courseID).enrolledStd.remove(index);
			if(!courseMap.get(term).get(courseID).avaialbe) {
				courseMap.get(term).get(courseID).avaialbe=true;
			}
			result="success";
		
		}finally {
			lock.unlock();
		}
		return result;
	}
	
	public String dropForStudent(String stdID, String courseID) {
		System.out.println("we are at drop for student");
		String term=" ";
		try {
			lock.lock();

		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				if (stdClients.get(i).registedCourse.containsKey(courseID)) {

				 term = stdClients.get(i).registedCourse.get(courseID).toLowerCase();
					if (term.equals("fall")) {
						stdClients.get(i).takeCourse[0]--;
					} else if (term.equals("winter")) {
						stdClients.get(i).takeCourse[1]--;
					} else {
						stdClients.get(i).takeCourse[2]--;
					}

			    stdClients.get(i).registedCourse.remove(courseID, term);
				}
			}
		}
		}finally {
			lock.unlock();
		}
		System.out.println("we are get the term"+term);
		return term;
	  }

	

	@Override
	public String getClassSchedule(String stdID)  {

		String result = " ";	
		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				
				for(String key:stdClients.get(i).registedCourse.keySet()) {
					result +=stdClients.get(i).registedCourse.get(key)+": "+key+"  ";
				}				
			}
		}
		System.out.println(result);
		try {
			Log(Department, getData() + " Student " + stdID + " class schedule is "+ result);
		}catch (Exception e) {
			e.printStackTrace();
		}

		return result;

	}
	
	
	@Override
	public String changeCourse(String stdID, String oldID, String newID) {
		String result="";
		String term=enrolled(stdID, oldID);
		System.out.println("the stdID enrolled in oldID term is "+ term);
		

		
		if(!term.equals("")) {
			
//			String nterm=enrolled(stdID, newID);                 //this is the place where i changed 
//			if(!nterm.equals(" ")) {
//			System.out.println("This class new class already enrolled");
//			result="fail";
//			
//			}else {
			int otherCourse=getOtherDept(stdID);
			System.out.println("The student enroll in other dept course is "+ otherCourse);
			int newCourseSpace=checkCourseSpace(term, stdID, stdID, newID);
			System.out.println("The newID course "+newID+ " space is "+newCourseSpace);
			if((oldID.substring(0, 4).equals(newID.substring(0,4)) || newID.substring(0, 4).equals(Department)||otherCourse<2 ||
					((!oldID.substring(0,4).equals(Department) &&( !newID.substring(0,4).equals(Department)))))&& (newCourseSpace>0)) {
				System.out.println("we are at center of the changeCourse, and plan to swapcourseLocal now: ");
				swapCourseLocal(stdID, oldID, newID, term);
				result="success";
			}
		}
		//}
		if(result.equals("")) {
			result="fail";
		}
		return result;
		
	}
	
	
	
	public void swapCourseLocal(String stdID, String oldID, String newID,String term) {
		String result="";
		try {
			lock.lock();	
			dropCourse(stdID, oldID);
			enrollCourse(stdID, newID, term);      // I changed here.
			
//			if(!dropCourse(stdID, oldID)){
//				System.out.println("drop course fail");
//			}
//			else{
//					result=enrollCourse(stdID, newID, term);
//					if(result.contains("fa")) {             //assumption: there is a problem, it should be 
//						System.out.println("enroll new course fail");
//						enrollCourse(stdID, oldID, term);
//					}
//					else {
//						
//					}
//				}
				
		} finally {
			lock.unlock();
		}
	}
	
	


	
	public String enrolled(String stdID, String courseID) {
		String result="";
	
		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(stdID)) {

					if(stdClients.get(i).registedCourse.containsKey(courseID)) {
						result=stdClients.get(i).registedCourse.get(courseID);
					}
	
			}
		}
		return result;
	}
	
	public int getOtherDept(String stdID) {
		int count=0;
		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(stdID)) {

				for(String key:stdClients.get(i).registedCourse.keySet()) {
					if(!key.substring(0,4).equals(Department)) {
						count++;
					}
				}
				break;
			}
		}
		return count;
		
	}
	
	
	public int checkCourseSpace(String term, String advID, String stdID,String courseID) {
		int result=0;
		try {
			
		lock.lock();
		
		String anString=listCourseA(advID, term);
		if(anString.contains(courseID)) {
			int index=anString.indexOf(courseID);
			String substring=anString.substring(index, anString.length()-1);
			int secindex=substring.indexOf(",");
			String fsString=substring.substring(8, secindex);
			result=Integer.valueOf(fsString.trim());	
		}
		
		System.out.println("the result of this class is "+result);
	
	} finally {
		lock.unlock();
	}
	 return result;

     }
}