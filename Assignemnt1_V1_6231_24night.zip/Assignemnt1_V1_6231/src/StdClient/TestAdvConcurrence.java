package StdClient;

import java.util.ArrayList;


public class TestAdvConcurrence extends Thread{
	
////	static String Date = "2017-01-01";
////	static String RoomNumber = "214";
//	static ArrayList<String> classInformation = new ArrayList<>();
//	
//	
//	public void run(){
//		COMP.ServerService serverService = new COMP.ServerService();
//		COMP.ServerInterface serverInterface = serverService.getServerport();
//		
//		for(int i = 0; i < TimeSlots.size(); i++){
//			System.out.println(serverInterface.createRoom(RoomNumber, Date, TimeSlots.get(i), "DVLA"));
//		}
//		
//	}
//
//	public static void main(String[] args) {
//
//		
//		TestAdvConcurrency adv1 = new TestAdvConcurrency();
//		TestAdvConcurrency adv2 = new TestAdvConcurrency();
//		adv1.start();
//		adv2.start();
//	}
//	

}


