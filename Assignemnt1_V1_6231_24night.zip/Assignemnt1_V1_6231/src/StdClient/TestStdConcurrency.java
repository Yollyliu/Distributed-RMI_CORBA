package StdClient;

import java.util.ArrayList;



public class TestStdConcurrency extends Thread{
//    static ArrayList<String> TimeSlots = new ArrayList<>();
//	
//	public void run(){
//		
//		COMP.ServerService serverService = new COMP.ServerService();
//		COMP.ServerInterface serverInterface = serverService.getServerport();
//		for(int i = 0;i < TimeSlots.size(); i ++){
//			
//			//System.out.println(serverInterface.getAvailableTimeSlot("2017-01-01", "WSTS"));
//			String result = serverInterface.bookRoom("DVL", "214", "2017-01-01", TimeSlots.get(i), "KKLS");
//			if(result.equals(" "))
//				System.out.println("FAILED!");
//			else
//				System.out.println("DONE! booking ID : " + result);
//		}
//		//System.out.println(serverInterface.getAvailableTimeSlot("2017-01-01", "KKLS"));
//	}
//
//	public static void main(String[] args) {
//		
//		COMP.ServerService serverService = new COMP.ServerService();
//		COMP.ServerInterface serverInterface = serverService.getServerport();
//		System.out.println(serverInterface.getAvailableTimeSlot("2017-01-01", "KKLS"));
//		
//		TimeSlots.add("9:00-10:00");
//		TimeSlots.add("10:00-11:00");
//		TimeSlots.add("11:00-12:00");
//		serverInterface.studentLogin("KKLS");
//		
//		for(int i = 0; i < 32; i ++){
//			TestStuConcurrency stu1 = new TestStuConcurrency();
//			stu1.start();	
//		}	
//		
//		
//		
//	}
//	
	

}
