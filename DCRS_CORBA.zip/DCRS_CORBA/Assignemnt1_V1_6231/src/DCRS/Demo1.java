package DCRS;

public class Demo1 extends Thread{
    public static void main(String[] args) {
        CRImpl server1 = new CRImpl();
        server1.Department = "COMP";
        server1.addCourse("COMP6231", "summer","COMPA1111", "3");
        server1.addCourse("COMP6241", "summer","COMPA1111", "2");
        server1.addCourse("COMP6251", "summer", "COMPA1111", "2");
        server1.enrollCourse("COMPS1111", "COMP6231", "summer");
        server1.enrollCourse("COMPS2222", "COMP6241", "summer");
        server1.enrollCourse("COMPS3333", "COMP6231", "summer");
        server1.enrollCourse("COMPS4444", "COMP6241", "summer");
        server1.enrollCourse("COMPS5555", "COMP6231", "summer");
  

        Demo1 threadDemo1 = new Demo1(server1,"COMPS1111","COMP6231");
        threadDemo1.start();
        Demo1 threadDemo2 = new Demo1(server1,"COMPS2222","COMP6241");
        threadDemo2.start();
        Demo1 threadDemo3 = new Demo1(server1,"COMPS3333","COMP6231");
        threadDemo3.start();
        Demo1 threadDemo4 = new Demo1(server1, "COMPS4444","COMP6241");
        threadDemo4.start();
        Demo1 threadDemo5 = new Demo1(server1, "COMPS5555","COMP6231");
        threadDemo5.start();
//        Demo threadDemo2 = new Demo(server2);
//        threadDemo2.start();
//        Demo threadDemo3 = new Demo(server3);
//        threadDemo3.start();
    }

    private CRImpl server;
    private String stdID;
    private String oldID;

    public Demo1(CRImpl server,String stdID,String oldID ){
        this.server = server;
        this.stdID= stdID;
        this.oldID=oldID;
    }

    public void run(){
//        String stdID = "COMPS"+Getnum();
//        server.stdLogin(stdID);
//        System.out.println(stdID + " ENROLL START");
//        String result= server.enrollCourse(stdID, "COMP6231", "summer");
        
        String result=server.changeCourse(stdID, oldID, "COMP6251");
       
        
        if (result.contains("su")){
            System.out.println(stdID + " change course success");
        } else {
            System.out.println(stdID + " change course fail");
        }
    }

//
//    public static String Getnum(){
//        int x=(int)(Math.random()*9000)+1000;
//        String result = Integer.toString(x);
//        return result;
//    }
}