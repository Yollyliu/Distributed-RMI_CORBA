package DCRS;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class UDPRequest {

	public UDPRequest() {
		super();
	}
	
	public static String request(String command,int serverport) throws SocketException{
		
//		System.out.println("hi, we start in UDPRequest : request"+ serverport);
		String replymsg = " ";
		DatagramSocket requestsocket = new DatagramSocket();
		try {
			
			byte []m = command.getBytes();
			InetAddress ahost = InetAddress.getByName("localhost");
			DatagramPacket request = new DatagramPacket(m,m.length,ahost,serverport);
			requestsocket.send(request);
			
			byte []buffer = new byte[1000];		
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
			requestsocket.receive(reply);
			
			byte []message = new byte[reply.getLength()];
			System.arraycopy(buffer, 0, message, 0, reply.getLength());
			replymsg = new String(message);
//			System.out.println("The message in UDPRequest is"+ replymsg+ " from "+serverport);


		} 
		catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		}
		
		finally {
			if(requestsocket != null)
				requestsocket.close();
		}
			
		return replymsg;
	}
	
	public static String listCourseA(String command,int serverport) throws SocketException{
//		System.out.println("hi, we are in UPDRequest: listCourseA");
		String result = ""; 
		result = request(command, serverport);
		return result;	
	}
	
	public static String UDPenrollCourse(String command,int serverport) throws SocketException{
		String result = " ";
		result = request(command, serverport);
		return result;
	}
	
	public static String UDPdropCourse(String command,int serverport) throws SocketException{
		String result = " ";
		result = request(command, serverport);
		return result;
	}
	
	public static String UDPremoveCourse(String command,int serverport) throws SocketException{
//		System.out.println("we are at UDP request drop for student for "+ serverport);
		String result = " ";
		result = request(command, serverport);
//		System.out.println("the result of drop for student is"+ result+" in "+serverport);
		return result;
	}
	
	
}
