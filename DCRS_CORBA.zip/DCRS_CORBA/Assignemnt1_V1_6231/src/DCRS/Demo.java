package DCRS;

public class Demo extends Thread{
    public static void main(String[] args) {
        CRImpl server1 = new CRImpl();
        server1.Department = "COMP";
        server1.addCourse("COMP6231", "summer","COMPA1111", "1");
//        server1.addCourse("COMP6241", "summer", "COMPA1111", "2");
//        server1.enrollCourse("COMPS1111", "COMP6231", "summer");
//        
//        CRImpl server2=new CRImpl();
//        server2.Department="INSE";
//        server2.addCourse("INSE6231", "summer", "INSEA2222", "2");
//        server1.enrollCourse("COMPS1111", "INSE6231","summer");
//        server1.changeCourse("COMPS1111", "INSE6231", "COMP6241");
//        
//        
//        CRImpl server3=new CRImpl();
//        server3.Department="SOEN";
//        server3.addCourse("SOEN6841", "summer", "SOENA3333", "0");
        

        Demo threadDemo1 = new Demo(server1);
        threadDemo1.start();
        Demo threadDemo2 = new Demo(server1);
        threadDemo2.start();
        Demo threadDemo3 = new Demo(server1);
        threadDemo3.start();
        Demo threadDemo4 = new Demo(server1);
        threadDemo4.start();
        Demo threadDemo5 = new Demo(server1);
        threadDemo5.start();
//        Demo threadDemo2 = new Demo(server2);
//        threadDemo2.start();
//        Demo threadDemo3 = new Demo(server3);
//        threadDemo3.start();
    }

    private CRImpl server;

    public Demo(CRImpl server){
        this.server = server;
    }

    public void run(){
        String stdID = "COMPS"+Getnum();
        server.stdLogin(stdID);
        System.out.println(stdID + " ENROLL START");
        String result= server.enrollCourse(stdID, "COMP6231", "summer");
       
        
        if (result.contains("succ")){
            System.out.println(stdID + " ENROLL SUCCESSFULLY");
        } else {
            System.out.println(stdID + " ENROLL FAILED");
        }
    }


    public static String Getnum(){
        int x=(int)(Math.random()*9000)+1000;
        String result = Integer.toString(x);
        return result;
    }
}