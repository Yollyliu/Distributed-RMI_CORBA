package DCRS;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;

import DCRS.CInterface;
import DCRS.CInterfaceHelper;
import DCRS.Listening;
import DCRS.CRImpl;;

public class CRServer {
	
     public static void main(String[] args) throws Exception{
		

     
     InputStreamReader is = new InputStreamReader(System.in);
	 BufferedReader br = new BufferedReader(is);
	 int udpportnum = 0;
	 String dept = " ";
	 Scanner s = new Scanner(System.in);
	 System.out.println("Enter department");
	 dept = s.nextLine();
	 String name = " ";
	 try {      	
        ORB orb = ORB.init(args, null);
        POA rootpoa = (POA)orb.resolve_initial_references("RootPOA");
    	rootpoa.the_POAManager().activate();
    
    CRImpl crImpl = new CRImpl();
    crImpl.setORB(orb);

    	org.omg.CORBA.Object ref = rootpoa.servant_to_reference(crImpl);
 
    	CInterface href = CInterfaceHelper.narrow(ref);

    	org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");

    	NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
    
    	if(dept.equals("COMP")){
    		name = "DCRSCOMP";
    		udpportnum = 2111;
    	}
    	else if(dept.equals("INSE")){
    		name = "DCRSINSE";
    		udpportnum = 3222;
    	}
    		
    	else if(dept.equals("SOEN")){
    		name = "DCRSSOEN";
    		udpportnum = 4333;
    	}
    	else{
    		System.out.println("Server started failed");
			System.exit(0);
    	}
    	
    	NameComponent path[] = ncRef.to_name( name );
    	ncRef.rebind(path, href);
    	System.out.println("DCRS ready and waiting ...");
    	DatagramSocket serversocket = new DatagramSocket(udpportnum);
	        startlistening(dept, crImpl, udpportnum, serversocket);
	        crImpl.StartServer(dept);
    	orb.run();
        	
        } catch (Exception e) {
            System.out.println("!!!");
        }
 }
 
	
	private static void startlistening(String Depart, CRImpl departSever, int UDPlistenPort, DatagramSocket SeverSocket) throws Exception {
		
		String threadName = Depart + "listen";
		Listening listen = new Listening(threadName, SeverSocket, departSever);
		listen.start();
	}
	

}


	