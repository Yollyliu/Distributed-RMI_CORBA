import java.awt.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import org.omg.CORBA.PUBLIC_MEMBER;



import java.util.ArrayList;
import java.util.Date;

public class CRImpl extends UnicastRemoteObject implements CRInterf {  //one local server function inplement

	class StdClient {
		String studentID = "";
		int[] takeCourse = { 0, 0, 0 }; // 0:fall 1: winter 2:summer
		HashMap<String, String> registedCourse=new HashMap<>(); // key:courseID value: Term

	}

	class Course {
		public String courseID = "";
		public int capacity = 100;
		public int stdNumb = 0; // enrolled students number
		public LinkedList<String> enrolledStd = new LinkedList<>();
		public String roomID = "";
		public String prof = "";
		public boolean avaialbe = true;
	}

	class AdvClient {
		String advisorID = "";

	}

	LinkedList<StdClient> stdClients = new LinkedList<>();
	LinkedList<AdvClient> advClients = new LinkedList<>();


	HashMap<String, HashMap<String, Course>> courseMap = new HashMap<String, HashMap<String, Course>>();

	private String Department = "";

	protected CRImpl() throws RemoteException {
		super();


	}
	private Lock lock = new ReentrantLock();

	public static void Log(String Id, String psw) throws IOException {

		String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/ServerLog/"+ Id+".txt";
		FileWriter fileWriter = new FileWriter(path,true);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		bufferedWriter.write(psw + "\n");
		bufferedWriter.close();
	}

	public String getData() {
		Date date = new Date();
		long times = date.getTime();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String timeString = format.format(date);
		return timeString;
	}

	public void StartServer(String Depart) throws java.rmi.RemoteException {
		Department = Depart;
		try {
			Log(Department, getData() + " Server for " + Depart + " started");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Boolean advLogin(String advID) throws java.rmi.RemoteException {

		Boolean login = false;

		for (int i = 0; i < advClients.size(); i++) {
			if (advClients.get(i).advisorID.equals(advID)) {
				login = true;
				break;
			}
		}

		if (!login) {
			AdvClient advisor = new AdvClient();
			advisor.advisorID = advID;
			advClients.add(advisor);
		}

		System.out.println("Advisor: " + advID + " login");

		try {
			Log(Department, getData()+" Advisor: " + advID + " login.");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}

	public Boolean stdLogin(String stdID) throws java.rmi.RemoteException {

		Boolean exist = false;

		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				exist = true;
				break;
			}
		}

		if (!exist) {
			StdClient student = new StdClient();
			student.studentID = stdID;
			stdClients.add(student);
		}
		System.out.println("Student: " + stdID + " Login");

		try {
			Log(Department, getData()+ " Student: " + stdID + "Login");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}

	@Override
	public boolean addCourse(String courseID, String term, String advID, LinkedList<String> courseDetail)
			throws RemoteException {

		Boolean create = false;
		String courseDept=courseID.substring(0, 4);
		String advDept=advID.substring(0, 4);
		if(courseDept.equals(advDept)) {
		
		if(addCourseLocal(courseID, term, advID, courseDetail)) {
			create=true;
			try {
				System.out.println( "advisor " + advID + " add course " + courseID + " in " + term + " term.");
				Log(Department, getData()+ " advisor " + advID + " add course " + courseID + " in " + term + " term.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}
		}
		if(!create) {
			try {
				System.out.println(" advisor " + advID + " failed to add course " + courseID + " in " + term + " term.");
				Log(Department, " advisor " + advID + " failed to add course " + courseID + " in " + term + " term.");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}
		return create;
	}

	public boolean addCourseLocal(String courseID, String term, String advID, LinkedList<String> courseDetail) {
		synchronized(this) {
			if (courseMap.containsKey(term)) {               //all course are in courseMap
				if (courseMap.get(term).containsKey(courseID)) {      //this course already in the courseMap
					try {
						Log(Department, getData()+ " advisor " + advID + "fail to add course " + courseID 
								+ " in " + term + " term because this course already exist in this term.");
					} catch (Exception e) {
						e.printStackTrace();
					}
					
//					System.out.println("The course " + courseID + " already exists in " + term + " term");
					return false;
				} else {                 //this course not exist in the courseMap
					Course curCourse = new Course();
					curCourse.courseID = courseID;
					for (int i = 0; i < courseDetail.size(); i++) {
						String curInf = courseDetail.get(i).toString();

						if (curInf.contains("capacity")) {
							int cap = 100;
							String[] cur = curInf.split(" ");
							if (cur.length > 1) {
								cap = Integer.valueOf(cur[1]);
							}
							curCourse.capacity = cap;
						}

						if (curInf.contains("roomID")) {
							String roomID = curInf.replaceAll("roomID", "");
							curCourse.roomID = roomID;
						}

						if (curInf.contains("prof")) {
							String prof = curInf.replaceAll("prof", "");
							curCourse.prof = prof;
						}
					}
					courseMap.get(term).put(courseID, curCourse);   // this is the problem
//					System.out.println("The advisor +"+ advID+ "add this course "+ courseID+" successfull, this message is from CRImpl 1.");

					// courseMap.get(term).put(courseID, courseDetail);
					try {
						Log(Department, getData()+ " advisor " + advID + " add course " + courseID + " in " + term + " term.");
					} catch (Exception e) {
						e.printStackTrace();
					}
					return true;

				}
			} else {   //courseMap didnot have this term
				HashMap<String, Course> courseInf = new HashMap<String, Course>();
				Course curCourse = new Course();
				curCourse.courseID = courseID;
				for (int i = 0; i < courseDetail.size(); i++) {
					String curInf = courseDetail.get(i).toString();

					if (curInf.contains("capacity")) {
						int cap = 100;
						String[] cur = curInf.split(" ");
						if (cur.length > 1) {
							cap = Integer.valueOf(cur[1]);
						}
						curCourse.capacity = cap;
					}

					if (curInf.contains("roomID")) {
						String roomID = curInf.replaceAll("roomID", "");
						curCourse.roomID = roomID;
					}

					if (curInf.contains("prof")) {
						String prof = curInf.replaceAll("prof", "");
						curCourse.prof = prof;
					}
				}
				courseInf.put(courseID, curCourse);
				courseMap.put(term, courseInf);
//				System.out.println("The advisor +"+ advID+ "add this course "+ courseID+" successfull, this message is from CRImpl 2.");
			return true;
			
		}
		}
		
		
	}
//	
//	
	

	@Override
	public boolean removeCourse(String courseID, String term, String advID) throws RemoteException {

		boolean remove = false;
		int number = 0;
		if(courseID.substring(0, 4).equals(advID.substring(0, 4))) {
			synchronized (this ) {
				if (courseMap.containsKey(term)) {
					if (courseMap.get(term).containsKey(courseID)) {
						Course curCourse = new Course();
						curCourse = courseMap.get(term).get(courseID);
						number = curCourse.stdNumb;    // if students enroll in this course

						if (number != 0) {
							for (int i = 0; i < curCourse.enrolledStd.size(); i++) {
								String curResutl="";

								String curStdDepart=curCourse.enrolledStd.get(i).substring(0, 4);
								System.out.println("The student "+ curCourse.enrolledStd.get(i)+" enroll in this course. From removeCourse function.");
								if(curStdDepart.equals(Department)) {


									curResutl=dropForStudent(curCourse.enrolledStd.get(i), courseID);      // call the dropCourse function to delete student enroll in this course
								}
								else {
									System.out.println("we will connect the local server.");
									String curStd=curCourse.enrolledStd.get(i);

									String command = "removeCourse(" + curStd + "," + courseID +  ")";
									try {
										if (curStdDepart.equals("COMP")) {
											System.out.println("we will connect COMP server");
											curResutl = UDPRequest.UDPremoveCourse(command, 2111); // comp
											System.out.println("The result of dropForStudent"+curResutl);

										} else if (curStdDepart.equals("INSE")) {
											System.out.println("we will connect INSE server");
											curResutl = UDPRequest.UDPremoveCourse(command, 3222); // INSE
											System.out.println("The result of dropForStudent"+curResutl);
										} else {
											System.out.println("we will connect SOEN server");
											curResutl = UDPRequest.UDPremoveCourse(command, 4333); // SOEN
											System.out.println("The result of dropForStudent"+curResutl);

										}

									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}

						}
						courseMap.get(term).remove(courseID); // remove that record
						remove = true;
//				System.out.println("The course " + courseID + " is removed in " + term + " term by advisor " + advID);
						try {
							System.out.println(" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
							Log(Department,
									getData()+" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
						} catch (Exception e1) {
							e1.printStackTrace();
						}

					}

				}
			}
		}



		if(!remove) {
			try {
				System.out.println(" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");
				Log(Department, getData()+" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return remove;










//		boolean remove = false;
//		int number = 0;
//		if(courseID.substring(0, 4).equals(advID.substring(0, 4))) {
//		synchronized (this ) {
//		if (courseMap.containsKey(term)) {
//			if (courseMap.get(term).containsKey(courseID)) {
//				Course curCourse = new Course();
//				curCourse = courseMap.get(term).get(courseID);
//				number = curCourse.stdNumb;    // if students enroll in this course
//
//				if (number != 0) {
//					for (int i = 0; i < curCourse.enrolledStd.size(); i++) {
//
//						String curStdDepart=curCourse.enrolledStd.get(i).substring(0, 4);
//						dropCourse(curCourse.enrolledStd.get(i), courseID);      // call the dropCourse function to delete student enroll in this course
//
//					}
//
//				}
//				courseMap.get(term).remove(courseID); // remove that record
//				remove = true;
////				System.out.println("The course " + courseID + " is removed in " + term + " term by advisor " + advID);
//				try {
//					System.out.println(" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
//					Log(Department,
//							getData()+" advisor " + advID + " successfully remove course " + courseID + " in " + term + " term.");
//				} catch (Exception e1) {
//					e1.printStackTrace();
//				}
//
//			}
//
//		}
//		}
//		}
//			if(!remove) {
//				try {
//					System.out.println(" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");
//				Log(Department, getData()+" advisor " + advID + " failed to remove course " + courseID + " in " + term + " term");
//
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			}
//
//		return remove;

	}
	
	
	

	

	public String listCourseALocal(String term) {   //this work well 

//		System.out.println("Searching for Local Department Course Availability: "+Department);
		String result = " ";
		String curResult="";

		synchronized (this) {
			if (courseMap.containsKey(term)) {
				HashMap<String, Course> curTermMap = new HashMap<>();
				curTermMap = courseMap.get(term);
				Iterator iterator = curTermMap.keySet().iterator();
				while (iterator.hasNext()) {
					int restNum = 0;
					Course curCourse = new Course();
					curCourse = curTermMap.get(iterator.next());
					restNum = curCourse.capacity - curCourse.stdNumb;
					curResult =curResult+ curCourse.courseID + " " + Integer.toString(restNum) + ", ";
				}
			}
		}
		System.out.println("Done, the result of Course Availability in "+Department+" department is "+ curResult);

		return result=curResult;
	}

	@Override
	public String listCourseA(String advID, String term) throws RemoteException {

		String result = term + " - " + listCourseALocal(term);
		String depart = advID.substring(0, 4);
		String command = "listCourseA(" + term + ")";             //2018.0930 changed here 


		try {
			if (depart.equals("COMP")) {
				int serverport1 = 3222; // INSE
				int serverport2 = 4333; // SOEN
				
				System.out.println("Searching for INSE department course availbility");
				String result1=UDPRequest.listCourseA(command, serverport1);
//				System.out.println(result1);
			
				
				System.out.println("Searching for SOEN department course availbility");
				String result2=UDPRequest.listCourseA(command, serverport2);
//				System.out.println(result2);
				result = result + " " + result1+" "+result2;
				
			} else if (depart.equals("INSE")) {
				int serverport3 = 2111; // COMP
				int serverport4 = 4333; // SOEN
				System.out.println("Searching for COMP department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport3));
				String result3 =  UDPRequest.listCourseA(command, serverport3);
				
				System.out.println("Searching for SOEN department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport4));
				String result4 = UDPRequest.listCourseA(command, serverport4);
				result =result + " "+ result3 +" "+result4;
				
			} else {
				int serverport5 = 2111; // COMP
				int serverport6 = 3222; // INSE
				
				System.out.println("Searching for COMP department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport5));
				String result5 = UDPRequest.listCourseA(command, serverport5);
				
				System.out.println("Searching for INSE department course availbility");
//				System.out.println(UDPRequest.listCourseA(command, serverport6));
				String result6 = UDPRequest.listCourseA(command, serverport6);
				
				result =result + " "+ result5 +" "+result6;
			}

		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Log(Department, getData() + " Advisor ID " + advID + " check course aviability on " + term
					+" the result is"+ result);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean enrollCourse(String stdID, String courseID, String term) throws RemoteException {
		//if the student can enroll an other Department course, then use enrolCourseLocal
		String stdDepart=stdID.substring(0, 4);
		String courseDepart=courseID.substring(0,4);
		String command = "enrollCourse(" + stdID + "," + courseID + "," + term + ")" ;
		int otherDpNumb=0;
		
		String result=" ";

		String curTerm=term.toLowerCase();
		boolean exist=false;
		
		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(term)) {
				exist=true;
			}
		}
		if (!exist) {
			StdClient newStd=new StdClient();
			newStd.studentID=stdID;
			stdClients.add(newStd);
		}
		
		System.out.println("The size of stdClients : "+stdClients.size());
		for(int i=0;i<stdClients.size();i++) {
//			System.out.println("hello, we are going to find ");
//			System.out.println("The list of stdClients is :"+stdClients.get(i).studentID);
//			System.out.println("The student id is"+stdID);
			if(stdClients.get(i).studentID.equals(stdID) ){     //when student login, it will have record there
//			System.out.println("hello,  find student id");
			
			if(stdClients.get(i).registedCourse.containsKey(courseID)) {
				System.out.println("Student already in this couse.");
			}else {
	
//				if(!stdClients.get(i).registedCourse.containsKey(courseID)){
//					System.out.println("hello, the student is not registered this class");
			
				if((stdClients.get(i).takeCourse[0]<=2 && curTerm.equals("fall"))       //if that term is less or equal to 2 course
					|| (stdClients.get(i).takeCourse[1]<=2 && curTerm.equals("winter"))||
					(stdClients.get(i).takeCourse[2]<=2 && curTerm.equals("summer"))){
					
//					System.out.println("hello, find the student is not enroll in two course in one term ");
								
					try {
						String curResult=" ";
						if(stdDepart.toLowerCase().equals(courseDepart.toLowerCase())) {
//							System.out.println("The student want to enroll a course in his own department.");
							curResult = incertEnroll(stdID, courseID, curTerm);   // if the student is own department student
//							System.out.println("The result of this student is "+ result+" this message is from enrollCourse");
						}else {
							HashMap<String, String> curEnrolledMap=new HashMap<>();  //if the student is enrolled in other department 
							curEnrolledMap=stdClients.get(i).registedCourse;
							Iterator< String> iterator=curEnrolledMap.keySet().iterator();

							while(iterator.hasNext()) {     
								String key = iterator.next();
								String cur=key.substring(0, 4);          //cur is the courseID's department
								if(!cur.equals(stdDepart)) {
									otherDpNumb++;
								}
							}
							System.out.println(stdID+" enrolled in "+otherDpNumb+" course in other department");
							
							if( otherDpNumb<=1) {
								
								
								if(courseDepart.equals("COMP")) {
									System.out.println("We are going to use COMP server");
									curResult = UDPRequest.UDPenrollCourse(command, 2111);  //comp
								}
								else if(courseDepart.equals("INSE")) {
									System.out.println("We are going to use INSE server");
									curResult= UDPRequest.UDPenrollCourse(command, 3222);    //INSE
								}
								else {
									System.out.println("We are going to use COMP server");
									curResult= UDPRequest.UDPenrollCourse(command, 4333);     //SOEN
								}
//								System.out.println("The current state is "+ curResult);
	                         }							         
						}
						if(!curResult.equals(" ")) {
							result=enrollCourseLocol(stdID, courseID, curTerm);
//							if(!result.equals(" ")) {
//								return true;
//							}
							
						}
						
					} catch (Exception e) {
						
					
				}
			
			}
			}
			break;
			}
			
		}	

		if(result.equals(" ")){
			System.out.println("Student " + stdID + " failed to enrolled in "+ courseID+ ". " );
			try {
				Log(Department, getData() + " Student " + stdID + " failed to enrolled in "+ courseID+ ". " );
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
		}else {
			System.out.println("Student "+ stdID+" is enroll in this class "+courseID);
//			System.out.println(result);
			try {
				Log(Department, getData()+" Student "+ stdID+" successfully enrolled in this class "+courseID);
			}catch (Exception e) {
				e.printStackTrace();
			}
			return true;
		}

	}

	public String enrollCourseLocol(String stdID, String courseID, String term) {
		
		String result=" ";

//			System.out.println("WE are changing the student information");
			synchronized(this) {
				for (int i = 0; i < stdClients.size(); i++) {
					if (stdClients.get(i).studentID.equals(stdID)) {
						System.out.println("we are add course number in related term. This message is from enrollCourseLocal");
						
						stdClients.get(i).registedCourse.put(courseID, term);     // put course in that semster
						
						if (term.equals("fall")) {
							stdClients.get(i).takeCourse[0]++;    //term course add 1
//							System.out.println("fall add 1,Done. This message is from enrollCourseLocal");
						} else if (term.equals("winter")) {
							stdClients.get(i).takeCourse[1]++;
						} else {
							stdClients.get(i).takeCourse[2]++;
						}
						
						result="success";
						System.out.println("The result is "+ result+ " This message is from enrollCourseLocal");
//						break;

						
						return result;

					}
				}
			}
//			System.out.println("The result of the enrollCourseLoal is"+ result+" This message from enrollCourseLocal");
			return result;
			
		}

		
		

	
	public String incertEnroll(String stdID, String courseID, String term){     //need to return a string for enroll result
		
		System.out.println("We are at the incertEnroll function and want to put the student in it.");
		String result=" ";
		synchronized (this) {
			System.out.println("Trying to enroll in incertEnroll "+ Department);
			if (courseMap.containsKey(term)) {       //which departemt courseMap
				if (courseMap.get(term).containsKey(courseID)) {    //so it was all wrong when use iterator					
					if(courseMap.get(term).get(courseID).avaialbe) {
//						System.out.println("This course is available. ");
						courseMap.get(term).get(courseID).enrolledStd.add(stdID);
						courseMap.get(term).get(courseID).stdNumb++;
						if(courseMap.get(term).get(courseID).stdNumb==courseMap.get(term).get(courseID).capacity) {
							courseMap.get(term).get(courseID).avaialbe=false;
						}
						result="success";
					}
				}
			}
		}
		return result;
	}
	

	@Override
	public boolean dropCourse(String stdID, String courseID) throws RemoteException {

		String stdDepart = stdID.substring(0, 4);
		String courseDepart = courseID.substring(0, 4);
		String result=" ";
		
		String term=dropForStudent(stdID, courseID);
		if(term.equals(" ")) {
			return false;
		}else {
		

		String command = "dropCourse(" + stdID + "," + courseID + ","+term+ ")";
		if (stdDepart.equals(courseDepart)) {

			result= dropCourseLocal(stdID, courseID,term);
		} else {
			try {
				if (courseDepart.equals("COMP")) {
					result = UDPRequest.UDPdropCourse(command, 2111); // comp
				} else if (courseDepart.equals("INSE")) {
					result = UDPRequest.UDPdropCourse(command, 3222); // INSE
				} else {
					result = UDPRequest.UDPdropCourse(command, 4333); // SOEN
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

//			return true;
		}
		if(result.equals(" ")){
			System.out.println("studentClient " + stdID + " failed to drop "+ courseID+ " course." );
			try {
				Log(Department, getData() + "Student " + stdID + " failed to drop "+ courseID+ " course." );
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
		}else {
			
			System.out.println(result);
			try {
				Log(Department, getData() + " Student " + stdID + " success to drop "+ courseID+ " course.");
			}catch (Exception e) {
				e.printStackTrace();
			}
			return true;
		}
	
	}

	public String dropCourseLocal(String stdID, String courseID, String term) {

		String result=" ";
//		String term=dropForStudent(stdID, courseID);
//		if(term.equals(" ")) {
//			return term;
//		}
		synchronized (this) {
			
			courseMap.get(term).get(courseID).stdNumb--;
			int index=courseMap.get(term).get(courseID).enrolledStd.indexOf(stdID);
			courseMap.get(term).get(courseID).enrolledStd.remove(index);
			if(!courseMap.get(term).get(courseID).avaialbe) {
				courseMap.get(term).get(courseID).avaialbe=true;
			}
			result="success";
		
		}
		return result;
	}
	
	public String dropForStudent(String stdID, String courseID) {
		String term=" ";
		synchronized (this) {

		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				if (stdClients.get(i).registedCourse.containsKey(courseID)) {

				 term = stdClients.get(i).registedCourse.get(courseID).toLowerCase();
					if (term.equals("fall")) {
						stdClients.get(i).takeCourse[0]--;
					} else if (term.equals("winter")) {
						stdClients.get(i).takeCourse[1]--;
					} else {
						stdClients.get(i).takeCourse[2]--;
					}

			    stdClients.get(i).registedCourse.remove(courseID, term);
				}
			}
		}
		}
		return term;
	  }

	@Override
	public String getClassSchedule(String stdID) throws RemoteException {

		String result = " ";	
		for (int i = 0; i < stdClients.size(); i++) {
			if (stdClients.get(i).studentID.equals(stdID)) {
				
				for(String key:stdClients.get(i).registedCourse.keySet()) {
					result +=stdClients.get(i).registedCourse.get(key)+": "+key+"  ";
				}				
			}
		}
		System.out.println(result);
		try {
			Log(Department, getData() + " Student " + stdID + " class schedule is "+ result);
		}catch (Exception e) {
			e.printStackTrace();
		}

		return result;

	}

	public String changeCourse(String stdID, String oldID, String newID) throws RemoteException{
		String result="";
		String term=enrolled(stdID, oldID);
		if(!term.equals("")) {
			System.out.println("hi,we find term in changeCourse");
			int otherCourse=getOtherDept(stdID);     //get other dept course
			int newCourseSpace=checkCourseSpace(term, stdID, stdID, newID);  //check new course space
			if(newCourseSpace>0){
				System.out.println("we find new course have space");
			   if(oldID.substring(0, 4).equals(newID.substring(0,4)) ||
					newID.substring(0, 4).equals(Department)||otherCourse<2
					||(!newID.substring(0,4).equals(Department) && !oldID.substring(0,4).equals(Department))) {
				   System.out.println("the condition is ok, we can use it");
				   swapCourseLocal(stdID, oldID, newID, term);
				    result = "success";
			   }
			}
		}

		getClassSchedule(stdID);
		if(result.equals("")){
			result="fail";
		}
		return result;

	}


	public void swapCourseLocal(String stdID, String oldID, String newID,String term) throws RemoteException {
		String result="";
		try {
			lock.lock();
			System.out.println("hello, we are in swapCourseLocal, and drop then enroll course");
			dropCourse(stdID,oldID);
			enrollCourse(stdID,newID,term);
//			if(dropCourse(stdID, oldID)){
//
//
//
//				if(!enrollCourse(stdID, newID, term)) {
//					enrollCourse(stdID, oldID, term);
//				}
//			}

		} finally {
			lock.unlock();
		}

	}



	public String enrolled(String stdID, String courseID) {
		String result="";

		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(stdID)) {

				if(stdClients.get(i).registedCourse.containsKey(courseID)) {
					result=stdClients.get(i).registedCourse.get(courseID);
				}

			}
		}
		return result;
	}

	public int getOtherDept(String stdID) {
		int count=0;
		for(int i=0;i<stdClients.size();i++) {
			if(stdClients.get(i).studentID.equals(stdID)) {

				for(String key:stdClients.get(i).registedCourse.keySet()) {
					if(!key.substring(0,4).equals(Department)) {
						count++;
					}
				}
				break;
			}
		}
		System.out.println("The "+ stdID+ "is enrolled in "+ count+ "in other department");
		return count;

	}


	public int checkCourseSpace(String term, String advID, String stdID,String courseID) throws RemoteException{
		int result=0;
		System.out.println("we are check course space");
		try {
			String anString = listCourseA(advID, term);
			System.out.println("the result of listCourseA is");
			System.out.println(result);
			if(anString.contains(courseID)) {
				int index=anString.indexOf(courseID);
				String substring=anString.substring(index, anString.length()-1);
				int secindex=substring.indexOf(",");
				String fsString=substring.substring(8, secindex);
				result=Integer.valueOf(fsString.trim());
				System.out.println("the new course space is "+ result+" course");
			}

			return result;
		}catch (Exception e){

		}
		return result;


	}

}
