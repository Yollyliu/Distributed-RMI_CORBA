import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CRServer {
	
     public static void main(String[] args) throws Exception{
		
		InputStreamReader is = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(is);
	    String portNum = " ", registryURL = " ";
	    int udpportnum = 0;
	 
	    try{     
	    	
	    	if(args[0].equals("COMP")){
	    		portNum = "1111";
	    		udpportnum = 2111;
	    	}
	    	else if(args[0].equals("INSE")){
	    		portNum = "2222";
	    		udpportnum = 3222;
	    	}
	    	else if(args[0].equals("SOEN")){
	    		portNum = "3333";
	    		udpportnum = 4333;
	    	}
	    	else {
	    		System.out.println("Server started failed");
				System.exit(0);
			}
	        int RMIPortNum = Integer.parseInt(portNum);
	        startRegistry(RMIPortNum);
	        CRImpl obj = new CRImpl();
	        registryURL = "rmi://localhost:" + portNum + "/DCRS-" + args[0];
	        Naming.rebind(registryURL, obj);
	        System.out.println ("Server registered.  Registry currently contains:");
	        listRegistry(registryURL); 
	        System.out.println(" Hello Server ready. ");
	        
	        DatagramSocket serversocket = new DatagramSocket(udpportnum);
	        startlistening(args[0], obj, udpportnum, serversocket);

	        obj.StartServer(args[0]);
	         
	    }	      
	      catch (Exception re) {
	         System.out.println("Exception in Server.main: " + re);
	      } 
	  } 
	
	
	private static void startlistening(String Depart, CRImpl departSever, int UDPlistenPort, DatagramSocket SeverSocket) throws Exception {
		
		String threadName = Depart + "listen";
		Listening listen = new Listening(threadName, SeverSocket, departSever);
		listen.start();
	}
	
	private static void startRegistry(int RMIPortNum) throws RemoteException {
		
		try {
			Registry registry = LocateRegistry.getRegistry(RMIPortNum);
		    registry.list( ); 
		} catch (RemoteException e) { 		
		    Registry registry = LocateRegistry.createRegistry(RMIPortNum);
		    System.out.println("RMI registry created at port " + RMIPortNum);
		}
	}
		 
	private static void listRegistry(String registryURL) throws RemoteException, MalformedURLException {
		
		String [ ] names = Naming.list(registryURL);
		for (int i=0; i < names.length; i++)
			System.out.println(names[i]);
	}
}


	