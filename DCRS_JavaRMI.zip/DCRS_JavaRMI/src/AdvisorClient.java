import java.rmi.Naming;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.util.LinkedList;




public class AdvisorClient {

    public static void Log(String ID,String Message) throws Exception{
		
		String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/CLientLog/" + ID + ".txt";
		FileWriter fileWriter = new FileWriter(path,true);
		BufferedWriter bf = new BufferedWriter(fileWriter);
		bf.write(Message + "\n");
		bf.close();
	}
	
	public static String getDate(){
	    Date date = new Date();
	    long times = date.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String dateString = formatter.format(date);
	    return dateString;
	}
	
	public static boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
	
	public static boolean isStudent(String studentID) {
		String curDepart=studentID.substring(0, 4);
		String lastFour=studentID.substring(5);
        
        if( studentID.charAt(4)=='S' && lastFour.length()==4 && isInteger(lastFour)) {
	         if(curDepart.equals("COMP") ||curDepart.equals("INSE")||curDepart.equals("SOEN") ) {
	        	      return true;
	        	 }
	         return false;
        }
       return false;
		
	}

	public static boolean isCourse(String courseID){
		String dept=courseID.substring(0,4);
		String numid=courseID.substring(4);

		if(dept.equals("COMP") ||dept.equals("INSE") || dept.equals("SOEN")){
			if(isInteger(numid)){
				return true;
			}
		}
		return false;
	}
	
	
	public static void main(String args[]){
		try {
	         int RMIPort;         
	         String hostName,portNum = " ";
	         InputStreamReader is = new InputStreamReader(System.in);
	         BufferedReader br = new BufferedReader(is);
	         
	         System.out.println("Enter AdvisorID:");
	         Scanner Id = new Scanner(System.in);
	         String advisorID = Id.nextLine();
	         String depart = advisorID.substring(0,4);
	         String lastFour=advisorID.substring(5);
	         
	         if( advisorID.charAt(4)=='A' && lastFour.length()==4 && isInteger(lastFour)) {
		         if(depart.equals("COMP")) {
		        	      portNum = "1111";
		        	 }
		         else if(depart.equals("INSE")) {
		        	      portNum = "2222";
		        	 }
		         else if(depart.equals("SOEN")) {
		        	      portNum = "3333";
		        	 }else {
			        	 System.out.println("Invalid AdvisorID");
			        	 System.exit(0);
			         }

	         }
	         else {
	        	 System.out.println("Invalid AdvisorID");
	        	 System.exit(0);
	         }
	         
	        
	         RMIPort = Integer.parseInt(portNum);
	         String registryURL = "rmi://localhost:" + portNum + "/DCRS-" + depart;  

	         CRInterf cr = (CRInterf)Naming.lookup(registryURL);
	         System.out.println("Done " );
	                  
	         if(cr.advLogin(advisorID)){
	        	 System.out.println("Login successfully");
	        	 Log(advisorID, getDate() + " " + advisorID + " login successfully");
	         }
	         else{
	        	 System.out.println("Login Unsuccessfully");
	        	 Log(advisorID, getDate() + " " + advisorID + " login failed");
	         }
	         
	         while(true){
	        	 System.out.println(" ");
	        	 System.out.println("Please select an operation: ");
	        	 System.out.println("1: add Course");
	        	 System.out.println("2: remove Course");
	        	 System.out.println("3: list Course Availibility");
	        	 System.out.println("4: enroll Course");
	        	 System.out.println("5: get class Schedule");
	        	 System.out.println("6: drop course");
				 System.out.println("7: change course");
				 System.out.println("8: Exit" + "\n");
	        	 
	        	 Scanner s = new Scanner(System.in);
		         int input = s.nextInt();
	        	 switch (input) {
	        	 case 1: 
	        		
	        		 System.out.println("Please Enter Course ID:");
	        		 Scanner one = new Scanner(System.in);
	        		 String courseID = one.nextLine();
	        		 
	             System.out.println("Please Enter Course Term:");
	        		 Scanner two = new Scanner(System.in);
	        		 String term = two.nextLine();
	        		 
	        		 
	        		 System.out.println("Please Enter Capacity:");
	        		 Scanner three = new Scanner(System.in);
	        		 String cap=three.nextLine();
	        		 
	        		 
	        		 System.out.println("Please Enter Classroom ID:");
	        		 Scanner four = new Scanner(System.in);
	        		 String roomID = four.nextLine();
	        		 
	        		 System.out.println("Please Enter Professor information:");
	        		 Scanner five=new Scanner(System.in);
	        		 String prof=five.nextLine();
	        		 
	        		 
	        		 LinkedList<String> courseDetail = new LinkedList<>();
	        		 String first="capacity "+cap;
	        		 String second="roomID"+roomID;
	        		 String third="prof"+prof;
	        		 
	        		 courseDetail.add(first);
	        		 courseDetail.add(second);
	        		 courseDetail.add(third);
	        		 
	        		 
	        		
	        		 if(cr.addCourse(courseID, term, advisorID,  courseDetail)) {	
	        			 System.out.println("Add this course successfully! This message comes from AdvisorClient. ");
	        			 Log(advisorID, getDate() + " " + advisorID + " successfully add course. " 
	        			 + "Course information: Term: " + term + " CourseID: " + courseID + " Capacity: " + cap
	        			 +" Classroom: "+roomID+ " Prof: "+ prof);
	        			 break;
	        		 }
	        		 else{
	        			 System.out.println("Add course failed!"); 
	        			 Log(advisorID, getDate() + " " + advisorID + " failed to add course "+ courseID+
	        					 "in Term"+ term);
	        			 break;
	        		 }
	        		 
	        	 case 2:
	        		 
	        		 System.out.println("Please Enter Course ID");
	        		 Scanner six = new Scanner(System.in);
	        		 String cID = six.nextLine();
	        		 
	        		 System.out.println("Please Enter Term");
	        		 Scanner seven = new Scanner(System.in);
	        		 String cT = seven.nextLine();
	        		 

	        		 if(cr.removeCourse(cID,cT, advisorID)){
	        			 System.out.println("Remove "+ cID +" successfully in "+ cT+ " !");
	        			 Log(advisorID, getDate() + " " + advisorID + " remove "+ cID +" successfully. " 
	        			 + "Remove information: Course: " + cID + " in Term: " + cT);
	        		 }
	        		 else{
	        			 System.out.println("Delete this course Unsuccessfully!");
	        			 Log(advisorID, getDate() + " " + advisorID + " delete this course in failed");
	        		 }
	        		 break;
	        		 
	        	 case 3:
	        		 
	        		 System.out.println("Please Enter Term: ");
	        		 Scanner eight = new Scanner(System.in);
	        		 String curTerm = eight.nextLine();
	        		 System.out.println("Course Availibility of "+ curTerm+" :");
	        		 String result=cr.listCourseA(advisorID, curTerm);
	        		 System.out.println(result);
	        		 Log(advisorID, getDate()+" list course aviablity. Detail: "+ result);
	        		 break; 
	        	 case 4:
	        		 System.out.println("Please Enter StudentID: ");
	        		 Scanner nine1 = new Scanner(System.in);     		 
	        		 String sID = nine1.nextLine();
	        		 String stdDept=sID.substring(0,4);
	        		 
	        		 System.out.println("Please Enter CourseID: ");
	        		 Scanner nine = new Scanner(System.in);     		 
	        		 String courID = nine.nextLine();
	        		 
	        		 System.out.println("Please Enter Term: ");
	        		 Scanner ten = new Scanner(System.in);     		 
	        		 String termT = ten.nextLine();
	        		
	        		 if(isStudent(sID)&& (stdDept.equals(depart))) {
	        		 System.out.println("The student : "+sID+" The course is : "+ courID+" the term is : "+ termT);
	        		 if(cr.enrollCourse(sID,courID, termT)){
	        			 System.out.println("Student "+sID+" successfully enrolled in course "+ courID);
	        			 Log(advisorID,  getDate() + " Adivisor: "+advisorID +" successfully let Student: " + sID + " to enrolled in course " + courID
	    	        			 +" in term "+ termT);
	        			 Log(sID,  getDate() + " Student: " + sID + " successfully enrolled in course " + courID+ " by advisor :"+ advisorID
	    	        			 +" in term "+ termT);
	        		 }
	        		 else {
	        			 System.out.println("Student "+ sID+ " failed to enroll in course "+ courID);
	        			 Log(advisorID, getDate() +" Adivisor: "+advisorID +" fail to let Student: " + sID + "  enroll in course " + courID
	    	        			 +" in term "+ termT);
	        			 Log(sID,  getDate() + " Student: " + sID + " fail to enrolled in course " + courID+ " by advisor :"+ advisorID
	    	        			 +" in term "+ termT);
	        		 }
	        		 }else {
	        			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	        			 
	        		 }
	        		 break;
	        		 
	        	 case 5:
	        		 System.out.println("Please Enter StudentID: ");
	        		 Scanner one5 = new Scanner(System.in);     		 
	        		 String stdID5 = one5.nextLine();
	        		 String std5Dept=stdID5.substring(0, 4);

	        		 if(isStudent(stdID5)&&(std5Dept.equals(depart))) {
	        		 String result5=cr.getClassSchedule(stdID5);
	        		 System.out.println( stdID5+ "course schedule: "+ result5);
        			 Log(advisorID, getDate() + " Advisor: "+advisorID+" got student " + stdID5 + " course schedule: " + result5);
        			 Log(stdID5, getDate() + " Student " + stdID5 + " course schedule: " + result5+ " got by advisor: "+advisorID);
	        		 }else {
	        			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	        		 }
        			 break;
        			 
	        	 case 6:
	        		 System.out.println("Please Enter StudentID: ");
	        		 Scanner one6 = new Scanner(System.in);     		 
	        		 String stdID6 = one6.nextLine();
	        		 String std6Dept=stdID6.substring(0, 4);
	        		 
	        		 System.out.println("Please Enter Course ID: ");
	        		 Scanner two6 = new Scanner(System.in);     		 
	        		 String cID6 = two6.nextLine();
	        		 
	        		 if(isStudent(stdID6)&& std6Dept.equals(depart)) {
	        		 if(cr.dropCourse(stdID6, cID6)){
	        			 System.out.println("Student "+stdID6+" successfully drop course "+ cID6);
	        			 Log(advisorID,  getDate() + " Advisor: "+advisorID+" successfuly let student " + stdID6 + " to drop course " + cID6);
	        			 Log(stdID6,  getDate() + " Student " + stdID6 + " successfully drop course " + cID6 +" by advisor: "+advisorID);
	    	        			 
	        		 }
	        		 else {
	        			 System.out.println("Student "+ stdID6+ " failed to drop  course "+ cID6);
	        			 Log(advisorID, getDate() + " Advisor: "+advisorID + " fail to let "+ stdID6 + " to drop in course " + cID6);
	        			 Log(stdID6, getDate() + " Student " + stdID6 + " failed to drop in course " + cID6+ " by advisor:"+advisorID);
	    	        			
	        		 }
	        		 }else {
	        			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	        		 }
	        		 break;
				 case 7:
					 System.out.println("Enter studentID");
					 Scanner input1 = new Scanner(System.in);
					 String stdID = input1.nextLine();
					 System.out.println("Enter oldID");
					 String oldID = input1.nextLine();
					 System.out.println("Enter newID");
					 String newID = input1.nextLine();
//					 String result7=cr.changeCourse(stdID,oldID,newID);
//					 System.out.println(result7);


					 if(isStudent(stdID)&& isCourse(newID) && isCourse(oldID)) {
//						 System.out.println("The student : "+stdID+" change the course is : "+ oldID+" to new course term is : "+ newID);
						 String ans=cr.changeCourse(stdID,oldID,newID);
						 System.out.println(ans);
						 if(ans.contains("success")){

							 System.out.println("Student "+stdID+" successfully change course "+ oldID+" to new course "+newID);
							 Log(advisorID,  getDate() + " Adivisor: "+advisorID +" successfully let Student: "
									 + stdID+" successfully change course "+ oldID+" to new course "+newID);
							 Log(stdID,  getDate() + " Student: " + stdID+
									 " successfully change course "+ oldID+" to new course "+newID);
						 }
						 else {
							 System.out.println("Student "+ stdID+ " failed to change course "+ oldID+" to new course term is : "+ newID);
							 Log(advisorID, getDate() +" Adivisor: "+advisorID +" fail to let Student: "+ stdID+
									 "  change course "+ oldID+" to new course term is : "+ newID);
							 Log(stdID,  getDate() + " Student: " +stdID+
									 " failed to change course "+ oldID+" to new course term is : "+ newID);
						 }
					 }else {
						 System.out.println("Invalid StudentID or courseID");

					 }


					 break;


	        	 case 8:
	        		 System.exit(0);
	  		
				default:
					break;
				}
	        	 
	         }
	         
	      } 
	      catch (Exception e) {
	         System.out.println("Exception in AdvisorClient: " + e);
	      } 
	}



}
