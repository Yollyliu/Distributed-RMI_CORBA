import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.Vector;

import org.omg.CORBA.PUBLIC_MEMBER;



public interface CRInterf extends Remote {
	
	public Boolean advLogin(String advID) throws java.rmi.RemoteException;
	
	public Boolean stdLogin(String stdID) throws java.rmi.RemoteException;

	
	public boolean addCourse(String courseID, String term, String advID, LinkedList<String> courseDetail) throws java.rmi.RemoteException;
	
	public boolean removeCourse(String courseID,String term, String advID) throws java.rmi.RemoteException;
	
	public String listCourseA(String advID,String term) throws java.rmi.RemoteException;
	
	public boolean enrollCourse(String studID,String courseID, String term)throws java.rmi.RemoteException;
	
	public boolean dropCourse(String studID, String courseID)throws java.rmi.RemoteException;
	
	public String getClassSchedule(String studID) throws java.rmi.RemoteException;

	public String changeCourse(String stdID, String oldID, String newID) throws RemoteException;
	
	

}
