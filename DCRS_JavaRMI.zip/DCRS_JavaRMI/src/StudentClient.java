import java.rmi.Naming;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.io.InputStreamReader;

public class StudentClient {
	
public static void Log(String ID,String Message) throws Exception{
		
		String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/ClientLog/" +ID + ".txt";   //no pathing at this time
		FileWriter fileWriter = new FileWriter(path,true);
		BufferedWriter bf = new BufferedWriter(fileWriter);
		bf.write(Message + "\n");
		bf.close();
	}

	public static boolean isStudent(String studentID) {
		String curDepart=studentID.substring(0, 4);
		String lastFour=studentID.substring(5);

		if( studentID.charAt(4)=='S' && lastFour.length()==4 && isInteger(lastFour)) {
			if(curDepart.equals("COMP") ||curDepart.equals("INSE")||curDepart.equals("SOEN") ) {
				return true;
			}
			return false;
		}
		return false;

	}


	public static String getDate(){
	    Date date = new Date();
	    long times = date.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String dateString = formatter.format(date);
	    return dateString;
	}
	
	public static boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}

	public static boolean isCourse(String courseID){
		String dept=courseID.substring(0,4);
		String numid=courseID.substring(4);

		if(dept.equals("COMP") ||dept.equals("INSE") || dept.equals("SOEN")){
			if(isInteger(numid)){
				return true;
			}
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		
		try {
	         int RMIPort;         
	         String hostName;
	         String portNum = " ";
	        
	         
	         System.out.println("Enter studentID:");
	         Scanner Id = new Scanner(System.in);
	         String studentID = Id.nextLine();
	         String depart = studentID.substring(0,4);

	         String lastFour=studentID.substring(5);
	         
	         if( studentID.charAt(4)=='S' && lastFour.length()==4 && isInteger(lastFour)) {
	        	 if(depart.equals("COMP")) {
		        	 portNum = "1111"; 
	        	 }
		         else if(depart.equals("INSE")) {
		        	 portNum = "2222";
		         }
		         else if(depart.equals("SOEN")) {
		        	 portNum = "3333";
		         }else {
		        	 System.out.println("Invalid StudentID");
		        	 System.exit(0);
		         }
	        
	         }
	         else {
	        	 System.out.println("Invalid StudentID");
	        	 System.exit(0);
	         }
	         
	         InputStreamReader is = new InputStreamReader(System.in);
	         BufferedReader br = new BufferedReader(is);

	         RMIPort = Integer.parseInt(portNum);
	         String registryURL = "rmi://localhost:" + portNum + "/DCRS-" + depart;  

	         CRInterf cr = (CRInterf)Naming.lookup(registryURL);
	         System.out.println("Done " );
	         
	         if(cr.stdLogin(studentID)){
	        	 System.out.println("Login successfully");
	        	 Log(studentID, getDate() + " " + studentID + " login successfully");
	         }
	         else{
	        	 System.out.println("Login failed");
	        	 Log(studentID, getDate() + " " + studentID + " login failed");
	         }
	         while(true){
	        	 System.out.println(" ");
	        	 System.out.println("Please select an operation: ");
	        	 System.out.println("1: enroll Course");
	        	 System.out.println("2: get class Schedule");
	        	 System.out.println("3: drop course");
				 System.out.println("4: change course");
	        	 System.out.println("5: Exit" + "\n");
	        	 
	        	 Scanner s = new Scanner(System.in);
		         int input = s.nextInt();
	        	 switch (input) {
	       
	        	 case 1:
	        		 System.out.println("Please Enter CourseID: ");
	        		 Scanner one = new Scanner(System.in);     		 
	        		 String courseID = one.nextLine();
	        		 
	        		 System.out.println("Please Enter Term: ");
	        		 Scanner two = new Scanner(System.in);     		 
	        		 String term = two.nextLine();
	        		
	        		 
	        		 System.out.println("The student :"+studentID+"The course is :"+ courseID+"the term is :"+ term);
	        		 if(cr.enrollCourse(studentID,courseID, term)){
	        			 System.out.println("Student "+studentID+" successfully enrolled in course "+ courseID);
	        			 Log(studentID,  getDate() + " " + studentID + " successfully enrolled in course " + courseID
	    	        			 +" in term "+ term);
	        		 }
	        		 else {
	        			 System.out.println("Student "+ studentID+ "failed to enroll in course "+ courseID);
	        			 Log(studentID, getDate() + " " + studentID + " failed to enroll in course " + courseID
	    	        			 +" in term "+ term);
	        		 }
	        		 break;
	        		 
	        	 case 2:
	        		 String result=cr.getClassSchedule(studentID);
	        		 System.out.println( studentID+ "course schedule: "+ result);
        			 Log(studentID, getDate() + " " + studentID + " course schedule: " + result);
        			 break;

	        	 case 3:
	        		 System.out.println("Please Enter Course ID: ");
	        		 Scanner three = new Scanner(System.in);     		 
	        		 String cID = three.nextLine();
	        		 
	        		 if(cr.dropCourse(studentID, cID)){
	        			 System.out.println("Student "+studentID+" successfully drop course "+ cID);
	        			 Log(studentID,  getDate() + " " + studentID + " successfully drop course " + cID);
	    	        			 
	        		 }
	        		 else {
						 System.out.println("Student " + studentID + "failed to drop  course " + cID);
						 Log(studentID, getDate() + " " + studentID + " failed to drop in course " + cID);
					 }
	        		 break;

	        		 case 4:
						 System.out.println("Enter oldID");
						 Scanner four = new Scanner(System.in);
						 String oldID = four.nextLine();
						 System.out.println("Enter newID");
						 String newID = four.nextLine();
//						 String result7=cr.changeCourse(studentID,oldID,newID);
//						 System.out.println(result7);


						 if(isStudent(studentID)&& isCourse(newID) && isCourse(oldID)) {
							 System.out.println("The student : "+studentID+" change the course is : "+ oldID+" to new course term is : "+ newID);
							 String ans=cr.changeCourse(studentID,oldID,newID);
							 System.out.println(ans);
							 if(ans.contains("succe")){
								 System.out.println("Student "+studentID+" successfully change course "+ oldID+" to new course "+newID);

								 Log(studentID,  getDate() + " Student: " + studentID+
										 " successfully change course "+ oldID+" to new course "+newID);
							 }
							 else {
								 System.out.println("Student "+ studentID+ " failed to change course "+ oldID+" to new course term is : "+ newID);

								 Log(studentID,  getDate() + " Student: " +studentID+
										 " failed to change course "+ oldID+" to new course term is : "+ newID);
							 }
						 }else {
							 System.out.println("Invalid StudentID or courseID");

						 }


						 break;


	        		 case 5:
	        		 System.exit(0);
				default:
					break;
				}
	        	 
	         }
	         
	      } 
	      catch (Exception e) {
	         System.out.println("Exception in StudentClient: " + e);
	      } 

	}

}
