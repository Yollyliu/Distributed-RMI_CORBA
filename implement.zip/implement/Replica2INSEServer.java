package src.implement;
public class Replica2INSEServer {

	
	public static void main(String[] args) {
		INSEImpl2 inse = new INSEImpl2();
		
//		inse.setServerName("INSE");
		
		Runnable receive = () -> {
			try{
			//port for receive
			inse.UDPreceiver(6766);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};

		Thread receivetread = new Thread(receive);
		receivetread.start();

		inse.invocationReceiver(1212);
	}
}
