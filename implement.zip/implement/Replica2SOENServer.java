package src.implement;
public class Replica2SOENServer {
	
	public static void main(String[] args) {
		SOENImpl2 soen = new SOENImpl2();
		
//		soen.setServerName("SOEN");
		
		Runnable receive = () -> {
			try{
			//port for receive
			soen.UDPreceiver(7877);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread receivetread = new Thread(receive);
		receivetread.start();
		
		soen.invocationReceiver(1213);
	}
}