package src.implement;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class INSEImpl2{

    private static final String localHostName = "INSE";

    //This HashMap contain the course name and capacity in different semester.
    private static HashMap<String, HashMap<String, Integer>> courseRecords = new HashMap<String, HashMap<String, Integer>>();

    //This HashMap contain the students' IDs in specific course.
    private static HashMap<String, List<String>> enrollist = new HashMap<String, List<String>>();

    //This HashMap contain the courses by the specific student ID.
    private static HashMap<String, HashMap<String, String>> students = new HashMap<String, HashMap<String, String>>();

    //This HashMap count the course number for each semester which the student has enrolled.
    private static HashMap<String, HashMap<String, Float>> courseLimit = new HashMap<String, HashMap<String, Float>>();

    //This HashMap count the number of courses which the student enrolled from other departments.
    private static HashMap<String,Float> deptlimit = new HashMap<>();

    //semname is a String Array to compare the semester from user input.
    private final static String[] semname = {"Fall", "Winter", "Summer"};

    //UserID records the current User's ID.

    //
//    public void setServerName(String name) {
//        localHostName = name;
//    }

    //
    public boolean Login(String id) {
//		ServerLogging.getLogMessage(localHostName, UserID + " login success");
        return true;
    }


    //
    public boolean addCourse(String courseID, String semester, float capacity) {

        HashMap<String, Integer> sem = new HashMap<String, Integer>();
        int cap = (int)capacity;
        System.out.println("Integer" + cap);
        //COMP advisor only can add COMP courses.
        System.out.println("localHostname:"+localHostName);
        System.out.println(courseID);
        if(courseID.contains(localHostName)) {
            for(int i = 0; i < 3; i++) {
                if(semester.equals(semname[i])) {
                    //Avoid null pointer errors.
                    synchronized (courseRecords) {
                        if(courseRecords.get(semester) == null) {
                            //ServerLogging.getLogMessage(localHostName, UserID + " Add "+ courseID + " in " + semester);
                            sem.put(courseID, cap);
                            //Add new course to HashMap courses
                            courseRecords.put(semester, sem);
                            //Update enrollist to response the action of add course.
                            enrollist.put(courseID+semester, null);
                            //ServerLogging.getLogMessage(localHostName, UserID + " Add "+ courseID +" success");
                            return true;
                        }
                        sem = courseRecords.get(semester);
                        sem.put(courseID, cap);
                        courseRecords.put(semester, sem);
                        enrollist.put(courseID+semester, null);
                        //ServerLogging.getLogMessage(localHostName, UserID + " Add "+ courseID +" success");
                        return true;
                    }
                }
            }
        }
        //ServerLogging.getLogMessage(localHostName, UserID + "Add "+ courseID +" failed");
        return false;
    }


    public boolean removeCourse(String courseID, String semester) {

        String reply = "";
        HashMap<String, Integer> sem = new HashMap<String, Integer>();

        for(int i = 0; i < 3; i++) {
            //Find the right semester.
            if(semester.equals(semname[i])) {
                synchronized (courseRecords) {
                    if(courseRecords.get(semester) == null) {
                        //ServerLogging.getLogMessage(localHostName, UserID + " " + courseID +" not exist in " + semester);
                        return false;
                    }

                    //Drop course if students has already enrolled this course.
                    List<String> namelist = enrollist.get(courseID+semester);
                    if(enrollist.get(courseID+semester) != null) {
                        Iterator<String> name = namelist.iterator();

                        while (name.hasNext()) {
                            String n = name.next();
                            //local modify
                            if(n.contains(localHostName)) {
                                //Remove course from students.
                                HashMap<String, String> enrolled = students.get(n);
                                enrolled.remove(courseID, semester);
                                students.put(n, enrolled);

                                //modify the course limit.
                                HashMap<String, Float> limit = courseLimit.get(n);
                                float m = limit.get(semester);
                                m = m - 1;
                                limit.put(semester, m);
                                courseLimit.put(n, limit);
                            }

                            //Remote modify
                            else if(n.contains("SOEN")) {
                                reply = UDPrequest(7877, "removeCourse." + n + "." + courseID + "." + semester);
                                //Check the reply status.
                                if(reply.contains("false")) {
                                    //ServerLogging.getLogMessage(localHostName, UserID + " Remove course to SOEN students failed");
                                    return false;
                                }
                            }else if(n.contains("INSE")) {
                                reply = UDPrequest(6766, "removeCourse." + n + "." + courseID + "." + semester);
                                //Check the reply status.
                                if(reply.contains("false")) {
                                    //ServerLogging.getLogMessage(localHostName, UserID + " Remove course to INSE students failed");
                                    return false;
                                }
                            }else if(n.contains("COMP")) {
                                reply = UDPrequest(5655, "removeCourse." + n + "." + courseID + "." + semester);
                                //Check the reply status.
                                if(reply.contains("false")) {
                                    //ServerLogging.getLogMessage(localHostName, UserID + " Remove course to COMP students failed");
                                    return false;
                                }
                            }
                        }
                        //Remove courseID from enrollist
                        enrollist.remove(courseID+semester, namelist);
                    }
                    //Remove course record from courseRecords.
                    sem = courseRecords.get(semester);
                    int n = sem.get(courseID);
                    sem.remove(courseID, n);
                    //ServerLogging.getLogMessage(localHostName, UserID + " Remove " + courseID + " success");
                    return true;
                }
            }
        }
        //ServerLogging.getLogMessage(localHostName, UserID + " Remove course failed");
        return false;
    }


    //
    public String listCourseAvailability(String semester) {

        String reply1 = null;
        String reply2 = null;
        String reply3 = null;
        //ServerLogging.getLogMessage(localHostName, UserID + " List course Available in " + semester);
        for(int i = 0; i < 3; i++) {
            //Find the right semester.
            if(semester.equals(semname[i])) {
                System.out.println("reach here");
                if(localHostName.contains("SOEN") == false) {
                    //UDP request for courses to SOEN server.
                    reply1 = UDPrequest(7877, "listCourseAvailability."+semname[i]);
                    //ServerLogging.getLogMessage(localHostName, "SOENServer reply: " + reply1);
                }

                if(localHostName.contains("INSE") == false) {
                    //UDP request for courses to INSE server.
                    reply2 = UDPrequest(6766, "listCourseAvailability."+semname[i]);
                    //ServerLogging.getLogMessage(localHostName, "INSEServer reply: " + reply2);
                }

                if(localHostName.contains("COMP") == false) {
                    //UDP request for courses to INSE server.
                    reply3 = UDPrequest(5655, "listCourseAvailability."+semname[i]);
                    //ServerLogging.getLogMessage(localHostName, "INSEServer reply: " + reply2);
                }
                System.out.println("SOEN"+reply1);
                System.out.println("INSE"+reply2);
                System.out.println("end");
                HashMap<String, Integer> sem = courseRecords.get(semname[i]);
                if(sem == null) {
                    String content = localHostName +"empty"+reply1+reply2+reply3;
                    String n1 = content.replaceAll("null", "").replaceAll("\\{", "").replaceAll("\\}", "").replaceAll("[\\000]*", "");
                    //ServerLogging.getLogMessage(localHostName, n1);
                    return n1;
                }
                String content = sem.toString()+reply1+reply2+reply3;
                String n1 = content.replaceAll("null", "").replaceAll("\\{", "").replaceAll("\\}", "").replaceAll("[\\000]*", "");
                //ServerLogging.getLogMessage(localHostName, n1);
                return n1;
            }
        }
        //ServerLogging.getLogMessage(localHostName, "List course available failed");
        return "failed";
    }


    //
    public boolean enrolCourse(String studentID, String courseID, String semester) {
        String reply = "";
        HashMap<String, String> enrolled = new HashMap<String, String>();
        List<String> namelist = new LinkedList<String>();

        //Determine which server the course is.
        if(courseID.contains(localHostName)) {

            for(int i = 0; i < 3; i++) {
                if(semester.equals(semname[i])) {
                    //check if the studentID exist in the courseLimit.
                    if (courseLimit.containsKey(studentID)) {
                        HashMap<String, Float> limit = courseLimit.get(studentID);
                        //check if the course number has reached the upper limit.
                        if(limit.get(semester) != null) {
                            if(limit.get(semester) >= 3) {
                                //ServerLogging.getLogMessage(localHostName, "List course available failed");
                                return false;
                            }
                        }
                    }
                    synchronized (courseRecords) {
                        //Check if there is course in this semester.
                        if(courseRecords.get(semester) == null) {
                            //ServerLogging.getLogMessage(localHostName, "No " + courseID + " in " + semester);
                            return false;
                        }
                        HashMap<String, Integer> sem = courseRecords.get(semester);
                        Set<String> courseSet = sem.keySet();
                        //Using loop to find the right course.
                        for(String courseKey : courseSet){
                            if(courseKey.equals(courseID)) {
                                int cap = sem.get(courseID);
                                //Check if there is any seat in this course.
                                if(cap > 0){
                                    //Modify the capacity.
                                    cap = cap-1;
                                    sem.put(courseID, cap);
                                    courseRecords.put(semester, sem);

                                    //Modify the HashMap of enroll list.
                                    for(i=0; i < 3; i++){
                                        if(enrollist.get(courseID+semname[i]) != null) {
                                            namelist = enrollist.get(courseID+semname[i]);
                                            for(String data : namelist) {
                                                if(data.equals(studentID)) {
                                                    //ServerLogging.getLogMessage(localHostName, studentID + " have already enrolled " + courseID + " in " + semname[i]);
                                                    return false;
                                                }
                                            }
                                        }
                                    }
                                    //Add student name to enroll list.
                                    if(enrollist.get(courseID+semester) == null) {
                                        namelist.add(studentID);
                                        enrollist.put(courseID+semester, namelist);
                                    } else {
                                        namelist = enrollist.get(courseID+semester);
                                        namelist.add(studentID);
                                        enrollist.put(courseID+semester, namelist);
                                    }

                                    if(studentID.contains(localHostName)) {
                                        //Modify the course list of student.
                                        if(students.get(studentID) == null) {
                                            enrolled.put(courseID, semester);
                                            students.put(studentID, enrolled);
                                        } else {
                                            enrolled = students.get(studentID);
                                            enrolled.put(courseID, semester);
                                            students.put(studentID, enrolled);
                                        }

                                        //Modify the course limit in that semester of student.
                                        if(courseLimit.get(studentID) == null) {
                                            //Modify the limits
                                            HashMap<String, Float> limit = new HashMap<String, Float>();
                                            limit.put("Fall", (float) 0);
                                            limit.put("Summer", (float) 0);
                                            limit.put("Winter", (float) 0);
                                            limit.put(semester, (float) 1);
                                            courseLimit.put(studentID, limit);
                                        } else {
                                            HashMap<String, Float> limit = courseLimit.get(studentID);
                                            Float m = limit.get(semester);
                                            m = m+1;
                                            limit.put(semester, m);
                                            courseLimit.put(studentID, limit);
                                        }
                                    }
                                    //ServerLogging.getLogMessage(localHostName, UserID + " " + studentID + " enroll "+ courseID +" success");
                                    return true;
                                }
                                //ServerLogging.getLogMessage(localHostName, UserID + " This "+ courseID +" is full");
                                return false;
                            }
                        }
                    }
                }
            }
            //ServerLogging.getLogMessage(localHostName, UserID + "Enrol failed" + courseID);
            
            return false;
        }

        //Enrol course on the remote server.
        //Check the department limit of the course.
        if(deptlimit.containsKey(studentID)) {
            //reach the limit of outter department course.
            if(deptlimit.get(studentID) >= 2) {
                //ServerLogging.getLogMessage(localHostName, UserID + studentID + "can not enrol course from other department any more");
                return false;
            }
        }
        //check if the studentID exist in the courseLimit.
        if (courseLimit.containsKey(studentID)) {
            HashMap<String, Float> limit = courseLimit.get(studentID);
            //Initial the limit
            if(limit.get(semester) == null) {
                //Initial the limits
                limit.put(semester, (float)0);
                courseLimit.put(studentID, limit);
            }
            //check if the course number has reached the upper limit.
            if(limit.get(semester) >= 3) {
                //ServerLogging.getLogMessage(localHostName, UserID + "course number in "+ semester +" has reached the upper limit");
                return false;
            }
        }
        //Enrol course on SOEN server.
        if(courseID.contains("SOEN")) {
            reply = UDPrequest(7877, "enrolCourse." + semester + "." + courseID + "." + studentID);
            //Check the reply status.
            if(reply.contains("true")) {
                //Modify department limit.
                if(deptlimit.get(studentID) == null) {
                    deptlimit.put(studentID, (float) 1);
                } else {
                    Float n = deptlimit.get(studentID);
                    n = n+1;
                    deptlimit.put(studentID, n);
                }
                //Modify course limit in that semester.
                if(courseLimit.get(studentID) == null) {
                    HashMap<String, Float> limit = new HashMap<String, Float>();
                    limit.put(semester, (float)1);
                    courseLimit.put(studentID, limit);
                }else {
                    HashMap<String, Float> limit = courseLimit.get(studentID);
                    Float m = limit.get(semester);
                    m = m+1;
                    limit.put(semester, m);
                    courseLimit.put(studentID, limit);
                }
                //Modify courselist for student.
                if(students.get(studentID) == null) {
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                } else {
                    enrolled = students.get(studentID);
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                }
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return false;
            }
        }
        //Enrol course on INSE server.
        if(courseID.contains("INSE")) {
            reply = UDPrequest(6766, "enrolCourse." + semester + "." + courseID + "." + studentID);
            //Check the reply status.
            if(reply.contains("true")) {
                //Modify department limit.
                if(deptlimit.get(studentID) == null) {
                    deptlimit.put(studentID, (float)1);
                } else {
                    Float n = deptlimit.get(studentID);
                    n = n+1;
                    deptlimit.put(studentID, n);
                }
                //Modify course limit in that semester.
                if(courseLimit.get(studentID) == null) {
                    HashMap<String, Float> limit = new HashMap<String, Float>();
                    limit.put(semester, (float) 1);
                    courseLimit.put(studentID, limit);
                }else {
                    HashMap<String, Float> limit = courseLimit.get(studentID);
                    float m = limit.get(semester);
                    m = m+1;
                    limit.put(semester, m);
                    courseLimit.put(studentID, limit);
                }
                //Modify courselist for student.
                if(students.get(studentID) == null) {
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                } else {
                    enrolled = students.get(studentID);
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                }
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return false;
            }
        }

        //Enrol course on COMP server.
        if(courseID.contains("COMP")) {
            reply = UDPrequest(5655, "enrolCourse." + semester + "." + courseID + "." + studentID);
            //Check the reply status.
            if(reply.contains("true")) {
                //Modify department limit.
                if(deptlimit.get(studentID) == null) {
                    deptlimit.put(studentID, (float)1);
                } else {
                    Float n = deptlimit.get(studentID);
                    n = n+1;
                    deptlimit.put(studentID, n);
                }
                //Modify course limit in that semester.
                if(courseLimit.get(studentID) == null) {
                    HashMap<String, Float> limit = new HashMap<String, Float>();
                    limit.put(semester, (float) 1);
                    courseLimit.put(studentID, limit);
                }else {
                    HashMap<String, Float> limit = courseLimit.get(studentID);
                    float m = limit.get(semester);
                    m = m+1;
                    limit.put(semester, m);
                    courseLimit.put(studentID, limit);
                }
                //Modify courselist for student.
                if(students.get(studentID) == null) {
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                } else {
                    enrolled = students.get(studentID);
                    enrolled.put(courseID, semester);
                    students.put(studentID, enrolled);
                }
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + reply);
                return false;
            }
        }
        //ServerLogging.getLogMessage(localHostName, UserID + "Not correct courseID" + courseID);
        return false;
    }



    //
    public boolean dropCourse(String studentID, String courseID) {

        String reply = "";
        List<String> namelist = new LinkedList<String>();

        //Check drop course from local server or remote server.
        if(courseID.contains(localHostName)) {

            for(int i = 0; i < 3; i++) {
                if(enrollist.containsKey(courseID+semname[i])) {
                    namelist = enrollist.get(courseID+semname[i]);
                    if(namelist == null) {
                        //ServerLogging.getLogMessage(localHostName, UserID + " No student in enrollist");
                        System.out.println("p1");
                        return false;
                    }

                    //Remove studentID from namelist.
                    if(namelist.contains(studentID)) {
                        namelist.remove(studentID);
                        enrollist.put(courseID+semname[i], namelist);

                        //Modify the capacity.
                        HashMap<String, Integer> sem = courseRecords.get(semname[i]);
                        int cap = sem.get(courseID);
                        sem.put(courseID, cap + 1);
                        courseRecords.put(semname[i], sem);

                        //If the student is the local department student.
                        if(studentID.contains(localHostName)) {

                            //Modify the course list of student.
                            HashMap<String,String> enrolled = students.get(studentID);
                            enrolled.remove(courseID, semname[i]);
                            students.put(studentID, enrolled);

                            //Modify the course limit in that semester of student.
                            HashMap<String, Float> limit = courseLimit.get(studentID);
                            Float m = limit.get(semname[i]);
                            m = m - 1;
                            limit.put(semname[i], m);
                            courseLimit.put(studentID, limit);
                        }
                        //drop course success.
                        //ServerLogging.getLogMessage(localHostName, UserID + " Drop "+ courseID + " for " + studentID + " success");
                        return true;
                    }
                    System.out.println("p2");
                    //ServerLogging.getLogMessage(localHostName, UserID + " " + studentID + " is not in this course");
                    return false;
                }
            }
            System.out.println("p3");
            //ServerLogging.getLogMessage(localHostName, UserID + " Remove "+ studentID +" from stuList failed");
            return false;
        }

        //Remote drop course
        if(courseID.contains("SOEN")) {
            System.out.println("p1");
            reply = UDPrequest(7877, "dropCourse." + studentID + "." + courseID);
            //Check the reply status.
            if(reply.contains("tr")) {

                //Modify department limit.
                Float n = deptlimit.get(studentID);
                n = n - 1;
                deptlimit.put(studentID, n);

                //Modify courselist for student.
                HashMap<String,String> enrolled = students.get(studentID);
                String semester = enrolled.get(courseID);
                enrolled.remove(courseID, semester);
                students.put(studentID, enrolled);

                //Modify course limit in that semester.
                HashMap<String, Float> limit = courseLimit.get(studentID);
                Float m = limit.get(semester);
                m = m - 1;
                limit.put(semester, m);
                courseLimit.put(studentID, limit);
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return false;
            }
        }

        if(courseID.contains("INSE")) {
            reply = UDPrequest(6766, "dropCourse." + studentID + "." + courseID);
            //Check the reply status.
            if(reply.contains("tr")) {

                //Modify department limit.
                Float n = deptlimit.get(studentID);
                n = n - 1;
                deptlimit.put(studentID, n);

                //Modify courselist for student.
                HashMap<String,String> enrolled = students.get(studentID);
                String semester = enrolled.get(courseID);
                enrolled.remove(courseID, semester);
                students.put(studentID, enrolled);

                //Modify course limit in that semester.
                HashMap<String, Float> limit = courseLimit.get(studentID);
                Float m = limit.get(semester);
                m = m - 1;
                limit.put(semester, m);
                courseLimit.put(studentID, limit);
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return false;
            }
        }

        //
        if(courseID.contains("COMP")) {
            reply = UDPrequest(5655, "dropCourse." + studentID + "." + courseID);
            //Check the reply status.
            if(reply.contains("tr")) {

                //Modify department limit.
                Float n = deptlimit.get(studentID);
                n = n - 1;
                deptlimit.put(studentID, n);

                //Modify courselist for student.
                HashMap<String,String> enrolled = students.get(studentID);
                String semester = enrolled.get(courseID);
                enrolled.remove(courseID, semester);
                students.put(studentID, enrolled);

                //Modify course limit in that semester.
                HashMap<String, Float> limit = courseLimit.get(studentID);
                Float m = limit.get(semester);
                m = m - 1;
                limit.put(semester, m);
                courseLimit.put(studentID, limit);
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return true;
            } else {
                //ServerLogging.getLogMessage(localHostName, UserID + " "+ reply);
                return false;
            }
        }

        //ServerLogging.getLogMessage(localHostName, UserID + " No such course.");
        return false;
    }


    //
    public String getClassSchedule(String studentID) {
        String str = "";
        if(students == null) {
            //ServerLogging.getLogMessage(localHostName, "Empty class schedule.");
            return "Empty class schedule.";
        }
        HashMap<String, String> Sche = students.get(studentID);
        if (Sche == null) {
            //ServerLogging.getLogMessage(localHostName, "Empty class schedule for " + studentID);
            return "empty";
        }
        //ServerLogging.getLogMessage(localHostName, Sche.toString());
        str = Sche.toString();
        str = str.replaceAll("\\{", "").replaceAll("\\}", "");
        if(str.equals("")) {
            return "empty";
        }
        return str;
    }

    //
    public boolean swapCourse(String studentID, String newCourseID, String oldCourseID) {

        HashMap<String, String> courselist = new HashMap<String, String>();
        boolean check = false;
        boolean reply = false;

        if(students.get(studentID) == null) {
            return false;
        }
        //check course have already enrolled.
        courselist = students.get(studentID);
        if(courselist.containsKey(oldCourseID)) {
            check = true;
        }
        String old = courselist.get(oldCourseID);

        if(check == true) {

            //reach the limit of outter department course.
            if(deptlimit.get(studentID) == null) {
                deptlimit.put(studentID, (float)0);
            } else {
                if (deptlimit.get(studentID) >= 2) {
                    if(newCourseID.contains(localHostName)== false) {
                        if(oldCourseID.contains(localHostName) == true) {
                            //ServerLogging.getLogMessage(localHostName, UserID + studentID + "can not enrol course from other department any more");
                            return false;
                        }
                        Float n = deptlimit.get(studentID);
                        n = n - 1;
                        deptlimit.put(studentID, n);
                    }
                }
            }

            //Modify course limit in that semester.
            HashMap<String, Float> limit = courseLimit.get(studentID);
            Float m = limit.get(old);
            m = m - 1;
            limit.put(old, m);
            System.out.println(m);
            courseLimit.put(studentID, limit);

            //
            limit = courseLimit.get(studentID);
            m = limit.get(old);
            System.out.println(m);

            //check if the new course is now available.
            reply = enrolCourse(studentID, newCourseID, old);

            if(reply == true) {
                boolean finalreply = dropCourse(studentID, oldCourseID);
                if (finalreply == true){
                    //Modify the course limit
                    limit = courseLimit.get(studentID);
                    m = limit.get(old);
                    m = m + 1;
                    System.out.println(m);
                    limit.put(old, m);
                    courseLimit.put(studentID, limit);
                    //ServerLogging.getLogMessage(localHostName, UserID + studentID + "swap course success");
                    return true;
                }
            }

            //Modify the course limit
            limit = courseLimit.get(studentID);
            m = limit.get(old);
            m = m + 1;
            limit.put(old, m);
            System.out.println(m);
            courseLimit.put(studentID, limit);
        }
        //ServerLogging.getLogMessage(localHostName, UserID + studentID + "swap fialed");
        return false;
    }

    //UDPrequest send
    public static String UDPrequest(int serverPort, String param) {
        DatagramSocket aSocket = null;
        try {
            aSocket = new DatagramSocket();
            byte[] message = param.getBytes();
            InetAddress aHost = InetAddress.getByName("localhost");
            DatagramPacket request = new DatagramPacket(message, param.length(), aHost, serverPort);
            aSocket.send(request);
            byte[] buffer = new byte[1000];
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
            aSocket.receive(reply);
            return new String(reply.getData());
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null)
                aSocket.close();
        }
        //ServerLogging.getLogMessage(localHostName, "failed");
        return "failed";
    }

    //UDPreceiver receive UDP request and choose the right method.
    public void UDPreceiver(int port) {
        byte[] result = null;
        String feedback = null;
        DatagramSocket aSocket = null;

        //
        try {
            aSocket = new DatagramSocket(port);
            byte[] buffer = new byte[1000];
            System.out.println("INSE2 UDPreceiver Started............");
            while (true) {
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(request);
                String str = new String(request.getData());
                String arg[] = str.split("\\.");
                String fliter = arg[0];
                //
                //compare method.
                System.out.println(fliter+".");
                if(fliter.equals("listCourseAvailability")) {
                    String semes = arg[1].trim();
                    if(semes.contains("Fall")) {
                        HashMap<String, Integer> c = courseRecords.get("Fall");
                        if(c != null) {
                            feedback = c.toString();
                            result = feedback.getBytes();
                        }
                    }
                    if(semes.contains("Winter")) {
                        HashMap<String, Integer> c = courseRecords.get("Winter");
                        if(c != null) {
                            feedback = c.toString();
                            result = feedback.getBytes();
                        }
                    }
                    if(semes.contains("Summer")) {
                        HashMap<String, Integer> c = courseRecords.get("Summer");
                        if(c != null) {
                            feedback = c.toString();
                            result = feedback.getBytes();
                        }
                    }
                    if(feedback == null) {
                        feedback = localHostName + "=empty";
                        result = feedback.getBytes();
                    }
                }

                //UDP removeCourse
                //arg[0] = method   arg[1] = studentID   arg[2] = courseID    arg[3].trim() = semester
                if(fliter.equals("removeCourse")) {
                    //ServerLogging.getLogMessage(localHostName, arg[1]+ " " + arg[2] + " " + arg[3].trim());
                    String semester = arg[3].trim();
                    //Remove course from students.
                    HashMap<String, String> enrolled = students.get(arg[1]);
                    if(enrolled.remove(arg[2], semester)) {
                        students.put(arg[1], enrolled);

                        //modify the course limit.
                        HashMap<String, Float> limit = courseLimit.get(arg[1]);
                        Float m = limit.get(semester);
                        m = m - 1;
                        limit.put(semester, m);
                        courseLimit.put(arg[1], limit);

                        //modify the department limit.
                        Float n = deptlimit.get(arg[1]);
                        n = n - 1;
                        deptlimit.put(arg[1], n);

                        feedback = "true";
                        result = feedback.getBytes();
                    }else {
                        feedback = "false";
                        result = feedback.getBytes();
                    }
                }

                //UDP enrolCourse
                //arg[0] = method   arg[1] = semester    arg[2] = courseID   arg[3].trim() = studentID
                if(fliter.equals("enrolCourse")) {
                    boolean fb = enrolCourse(arg[3].trim(), arg[2], arg[1]);
                    feedback = String.valueOf(fb);
                    result = feedback.getBytes();
                }

                //UDP dropCourse
                //arg[0] = method   arg[1] = studentID    arg[2] = couseID
                if(fliter.equals("dropCourse")){
                    boolean fb = dropCourse(arg[1], arg[2].substring(0, 8));
                    feedback = String.valueOf(fb);
                    result = feedback.getBytes();
                }
                
                if(fliter.equals("shutdown")) {
                	System.out.println("COMP UDPreceiver1 shutdowning");
                	aSocket.close();
                }
                
                if(result != null) {
                    DatagramPacket reply = new DatagramPacket(result, result.length, request.getAddress(), request.getPort());
                    aSocket.send(reply);
                }   

            }
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null)
                aSocket.close();
        }
    }

    public void alive(int port) {
        DatagramSocket aSocket = null;

        try {
            aSocket = new DatagramSocket(port);
            System.out.println("alive tread Started............");
            while (true) {
            	byte[] buffer = new byte[1000];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(request);
                String feedback = "hi";
                String str = new String(request.getData());
                if(str.length() > 0) {
                    byte[] result = feedback.getBytes();
                    DatagramPacket reply = new DatagramPacket(result, result.length, request.getAddress(), request.getPort());
                    aSocket.send(reply);
                }
            }
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null)
                aSocket.close();
        }
    }



    //replicaReceiver receive UDP request and return to RM.
    public void invocationReceiver(int port) {
//        byte[] result = null;
//        String feedback = null;
        DatagramSocket aSocket = null;

        //
        try {
//            byte[] result = null;
//            String feedback = null;
            aSocket = new DatagramSocket(port);
//            byte[] buffer = new byte[1000];
            System.out.println("INSE2 Server Started............");
            while (true) {
                byte[] buffer = new byte[1000];
                byte[] result = new byte[1000];
                String feedback = "";
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(request);
                String str = new String(request.getData());
                String arg[] = str.split("\\_");

                String fliter = arg[5];
                
                System.out.println("fliter = " + arg[5]);

                ///		ServerLogging.getLogMessage(localHostName, str);

                //compare method.
                if(fliter.equals("Login")) {
                    arg[6] = arg[6].trim();
                    //arg[6] = id
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] +"_" + arg[4] + "_"+ String.valueOf(Login(arg[6]));
                    result = feedback.getBytes();
                }

                if(fliter.equals("addCourse")) {
                    arg[8] = arg[8].trim();
                    //arg[6] = course id  arg[7] = semester arg[8] = capacity
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_"+ String.valueOf(addCourse(arg[6], arg[7], Float.parseFloat(arg[8])));
                    System.out.println(String.valueOf(addCourse(arg[6], arg[7], Float.parseFloat(arg[8]))));
                    result = feedback.getBytes();
                }

                if(fliter.equals("removeCourse")) {
                    arg[7] = arg[7].trim();
                    //arg[6] = course id  arg[7] = semester
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_"+ String.valueOf(removeCourse(arg[6], arg[7]));
                    result = feedback.getBytes();
                }

                if(fliter.equals("listCourseAvailability")) {
                    arg[6] = arg[6].trim();
                    //arg[6] = semester

                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_"+ listCourseAvailability(arg[6]);

                    result = feedback.getBytes();
                }

                if(fliter.equals("enrolCourse")) {
                    //arg[6] = student id    arg[7] = courseID   arg[8] = semester
                    arg[8] = arg[8].trim();
                    boolean fb = enrolCourse(arg[6], arg[7], arg[8]);
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_"+ String.valueOf(fb);
                    result = feedback.getBytes();
                }

                if(fliter.equals("dropCourse")){
                    //arg[6] = studentID    arg[7] = couseID
                    arg[7] = arg[7].substring(0, 8);
                    boolean fb = dropCourse(arg[6], arg[7]);
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_" + String.valueOf(fb);
                    result = feedback.getBytes();
                }

                if(fliter.equals("getClassSchedule")){
                    arg[6] = arg[6].trim();
                    //arg[5] = student id
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_" + getClassSchedule(arg[6]);
                    System.out.println("CoMPImpl feedback: "+feedback);
                    result = feedback.getBytes();
                }

                if(fliter.equals("swapCourse")){
                    arg[8] = arg[8].trim();
                    //arg[6] = student id  arg[7] = new course id  arg[8] = old course id
                    boolean fb = swapCourse(arg[6], arg[7], arg[8]);
                    feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_" + String.valueOf(fb);

                    result = feedback.getBytes();
                }

                if(fliter.equals("shutdown")) {
                	System.out.println("COMP1 shutdowning");
                	feedback = arg[0] + "_" + arg[1] + "_"+ arg[2] + "_" + arg[4] + "_" + "shutdown";
                	result = feedback.getBytes();
                    InetAddress host = InetAddress.getByName("localhost");
                    DatagramPacket reply = new DatagramPacket(result, result.length, host, 5555);
                    aSocket.send(reply);
                    aSocket.close();
                }
                
                if(feedback.equals("")) {
                	continue;
                }

                //arg[0] = IP Address  arg[1] = port
                InetAddress host = InetAddress.getByName("localhost");
                DatagramPacket reply = new DatagramPacket(result, result.length, host, 7000);
                aSocket.send(reply);
            }
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            //
           //feedback = null;
            if (aSocket != null)
                aSocket.close();
        }
    }
}
