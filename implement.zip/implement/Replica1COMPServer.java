package src.implement;
public class Replica1COMPServer extends Thread{
	
	
	public static void main(String[] args) {
		COMPImpl1 comp = new COMPImpl1();
//		comp.setServerName("COMP");
		Runnable receive = () -> {
			try{
			//port for receive
			comp.UDPreceiver(5555);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread receivetread = new Thread(receive);
		receivetread.start();
		
		Runnable alive = () -> {
			try{
			//port for receive
			comp.alive(9999);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		
		Thread alivetread = new Thread(alive);
		alivetread.start();

		comp.invocationReceiver(1111);
		
	}
}

