package src.implement;

public class Replica2COMPServer {

	
	
	public static void main(String[] args) {
		COMPImpl2 comp2 = new COMPImpl2();
		
		Runnable receive = () -> {
			try{
			//port for receive
			comp2.UDPreceiver(5655);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread receivetread = new Thread(receive);
		receivetread.start();
		
		Runnable alive = () -> {
			try{
			//port for receive
			comp2.alive(9090);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread alivetread = new Thread(alive);
		alivetread.start();
		
//		comp.setServerName("COMP");
		comp2.invocationReceiver(1211);

	}
}

