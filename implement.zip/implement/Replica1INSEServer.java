package src.implement;

public class Replica1INSEServer {
	
	public static void main(String[] args) {
		INSEImpl1 inse = new INSEImpl1();
//		inse.setServerName("INSE");
		Runnable receive = () -> {
			try{
			//port for receive
			inse.UDPreceiver(6666);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread receivetread = new Thread(receive);
		receivetread.start();

		inse.invocationReceiver(1112);
	}
}
