package src.implement;

public class Replica1SOENServer {
	
	public static void main(String[] args) {
		SOENImpl1 soen = new SOENImpl1();
//		soen.setServerName("SOEN");
		
		Runnable receive = () -> {
			try{
			//port for receive
			soen.UDPreceiver(7777);
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		Thread receivetread = new Thread(receive);
		receivetread.start();
		
		soen.invocationReceiver(1113);
	}
}