package Address;

public class AddressMap {
    private Address frontEnd;
    private Address sequencer;
    private Address replicaOne;
    private Address replicaTwo;
    private Address replicaThree;
    private Address replicaFour;

    public AddressMap(){
        frontEnd = new Address("frontEnd", "172.20.10.5", 2345);
        sequencer = new Address("sequencer", "172.20.10.5", 2000);
        replicaOne = new Address("Replica1", "172.20.10.5", 2020);
        replicaTwo = new Address("Replica2", "172.20.10.4", 2020);
        replicaThree = new Address("Replica3", "172.20.10.6", 2020);
        replicaFour = new Address("Replica4","172.20.10.3",2020);
    }

    public Address get(String name){
        if(name.equals("frontEnd")) return frontEnd;
        if(name.equals("sequencer")) return sequencer;
        if(name.equals("Replica1")) return replicaOne;
        if(name.equals("Replica2")) return replicaTwo;
        if(name.equals("Replica3")) return replicaThree;
        if(name.equals("Replica4")) return replicaFour;

        return null;

    }

}
