
package INSE;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the server package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListCourseAResponse_QNAME = new QName("http://Server/", "listCourseAResponse");
    private final static QName _RemoveCourse_QNAME = new QName("http://Server/", "removeCourse");
    private final static QName _AddCourseResponse_QNAME = new QName("http://Server/", "addCourseResponse");
    private final static QName _GetClassScheduleResponse_QNAME = new QName("http://Server/", "getClassScheduleResponse");
    private final static QName _SumoftwoResponse_QNAME = new QName("http://Server/", "sumoftwoResponse");
    private final static QName _DropCourseResponse_QNAME = new QName("http://Server/", "dropCourseResponse");
    private final static QName _ListCourseA_QNAME = new QName("http://Server/", "listCourseA");
    private final static QName _StdLoginResponse_QNAME = new QName("http://Server/", "stdLoginResponse");
    private final static QName _EnrollCourseResponse_QNAME = new QName("http://Server/", "enrollCourseResponse");
    private final static QName _GetClassSchedule_QNAME = new QName("http://Server/", "getClassSchedule");
    private final static QName _DropCourse_QNAME = new QName("http://Server/", "dropCourse");
    private final static QName _StdLogin_QNAME = new QName("http://Server/", "stdLogin");
    private final static QName _AddCourse_QNAME = new QName("http://Server/", "addCourse");
    private final static QName _ChangeCourse_QNAME = new QName("http://Server/", "changeCourse");
    private final static QName _Sumoftwo_QNAME = new QName("http://Server/", "sumoftwo");
    private final static QName _EnrollCourse_QNAME = new QName("http://Server/", "enrollCourse");
    private final static QName _RemoveCourseResponse_QNAME = new QName("http://Server/", "removeCourseResponse");
    private final static QName _AdvLogin_QNAME = new QName("http://Server/", "advLogin");
    private final static QName _AdvLoginResponse_QNAME = new QName("http://Server/", "advLoginResponse");
    private final static QName _ChangeCourseResponse_QNAME = new QName("http://Server/", "changeCourseResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: server
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EnrollCourse }
     * 
     */
    public EnrollCourse createEnrollCourse() {
        return new EnrollCourse();
    }

    /**
     * Create an instance of {@link AddCourse }
     * 
     */
    public AddCourse createAddCourse() {
        return new AddCourse();
    }

    /**
     * Create an instance of {@link ChangeCourse }
     * 
     */
    public ChangeCourse createChangeCourse() {
        return new ChangeCourse();
    }

    /**
     * Create an instance of {@link Sumoftwo }
     * 
     */
    public Sumoftwo createSumoftwo() {
        return new Sumoftwo();
    }

    /**
     * Create an instance of {@link DropCourse }
     * 
     */
    public DropCourse createDropCourse() {
        return new DropCourse();
    }

    /**
     * Create an instance of {@link StdLogin }
     * 
     */
    public StdLogin createStdLogin() {
        return new StdLogin();
    }

    /**
     * Create an instance of {@link AdvLogin }
     * 
     */
    public AdvLogin createAdvLogin() {
        return new AdvLogin();
    }

    /**
     * Create an instance of {@link AdvLoginResponse }
     * 
     */
    public AdvLoginResponse createAdvLoginResponse() {
        return new AdvLoginResponse();
    }

    /**
     * Create an instance of {@link ChangeCourseResponse }
     * 
     */
    public ChangeCourseResponse createChangeCourseResponse() {
        return new ChangeCourseResponse();
    }

    /**
     * Create an instance of {@link RemoveCourseResponse }
     * 
     */
    public RemoveCourseResponse createRemoveCourseResponse() {
        return new RemoveCourseResponse();
    }

    /**
     * Create an instance of {@link RemoveCourse }
     * 
     */
    public RemoveCourse createRemoveCourse() {
        return new RemoveCourse();
    }

    /**
     * Create an instance of {@link ListCourseAResponse }
     * 
     */
    public ListCourseAResponse createListCourseAResponse() {
        return new ListCourseAResponse();
    }

    /**
     * Create an instance of {@link EnrollCourseResponse }
     * 
     */
    public EnrollCourseResponse createEnrollCourseResponse() {
        return new EnrollCourseResponse();
    }

    /**
     * Create an instance of {@link GetClassSchedule }
     * 
     */
    public GetClassSchedule createGetClassSchedule() {
        return new GetClassSchedule();
    }

    /**
     * Create an instance of {@link StdLoginResponse }
     * 
     */
    public StdLoginResponse createStdLoginResponse() {
        return new StdLoginResponse();
    }

    /**
     * Create an instance of {@link DropCourseResponse }
     * 
     */
    public DropCourseResponse createDropCourseResponse() {
        return new DropCourseResponse();
    }

    /**
     * Create an instance of {@link ListCourseA }
     * 
     */
    public ListCourseA createListCourseA() {
        return new ListCourseA();
    }

    /**
     * Create an instance of {@link AddCourseResponse }
     * 
     */
    public AddCourseResponse createAddCourseResponse() {
        return new AddCourseResponse();
    }

    /**
     * Create an instance of {@link GetClassScheduleResponse }
     * 
     */
    public GetClassScheduleResponse createGetClassScheduleResponse() {
        return new GetClassScheduleResponse();
    }

    /**
     * Create an instance of {@link SumoftwoResponse }
     * 
     */
    public SumoftwoResponse createSumoftwoResponse() {
        return new SumoftwoResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListCourseAResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "listCourseAResponse")
    public JAXBElement<ListCourseAResponse> createListCourseAResponse(ListCourseAResponse value) {
        return new JAXBElement<ListCourseAResponse>(_ListCourseAResponse_QNAME, ListCourseAResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveCourse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "removeCourse")
    public JAXBElement<RemoveCourse> createRemoveCourse(RemoveCourse value) {
        return new JAXBElement<RemoveCourse>(_RemoveCourse_QNAME, RemoveCourse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddCourseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "addCourseResponse")
    public JAXBElement<AddCourseResponse> createAddCourseResponse(AddCourseResponse value) {
        return new JAXBElement<AddCourseResponse>(_AddCourseResponse_QNAME, AddCourseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClassScheduleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "getClassScheduleResponse")
    public JAXBElement<GetClassScheduleResponse> createGetClassScheduleResponse(GetClassScheduleResponse value) {
        return new JAXBElement<GetClassScheduleResponse>(_GetClassScheduleResponse_QNAME, GetClassScheduleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SumoftwoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "sumoftwoResponse")
    public JAXBElement<SumoftwoResponse> createSumoftwoResponse(SumoftwoResponse value) {
        return new JAXBElement<SumoftwoResponse>(_SumoftwoResponse_QNAME, SumoftwoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DropCourseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "dropCourseResponse")
    public JAXBElement<DropCourseResponse> createDropCourseResponse(DropCourseResponse value) {
        return new JAXBElement<DropCourseResponse>(_DropCourseResponse_QNAME, DropCourseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListCourseA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "listCourseA")
    public JAXBElement<ListCourseA> createListCourseA(ListCourseA value) {
        return new JAXBElement<ListCourseA>(_ListCourseA_QNAME, ListCourseA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StdLoginResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "stdLoginResponse")
    public JAXBElement<StdLoginResponse> createStdLoginResponse(StdLoginResponse value) {
        return new JAXBElement<StdLoginResponse>(_StdLoginResponse_QNAME, StdLoginResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnrollCourseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "enrollCourseResponse")
    public JAXBElement<EnrollCourseResponse> createEnrollCourseResponse(EnrollCourseResponse value) {
        return new JAXBElement<EnrollCourseResponse>(_EnrollCourseResponse_QNAME, EnrollCourseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClassSchedule }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "getClassSchedule")
    public JAXBElement<GetClassSchedule> createGetClassSchedule(GetClassSchedule value) {
        return new JAXBElement<GetClassSchedule>(_GetClassSchedule_QNAME, GetClassSchedule.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DropCourse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "dropCourse")
    public JAXBElement<DropCourse> createDropCourse(DropCourse value) {
        return new JAXBElement<DropCourse>(_DropCourse_QNAME, DropCourse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StdLogin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "stdLogin")
    public JAXBElement<StdLogin> createStdLogin(StdLogin value) {
        return new JAXBElement<StdLogin>(_StdLogin_QNAME, StdLogin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddCourse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "addCourse")
    public JAXBElement<AddCourse> createAddCourse(AddCourse value) {
        return new JAXBElement<AddCourse>(_AddCourse_QNAME, AddCourse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeCourse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "changeCourse")
    public JAXBElement<ChangeCourse> createChangeCourse(ChangeCourse value) {
        return new JAXBElement<ChangeCourse>(_ChangeCourse_QNAME, ChangeCourse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sumoftwo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "sumoftwo")
    public JAXBElement<Sumoftwo> createSumoftwo(Sumoftwo value) {
        return new JAXBElement<Sumoftwo>(_Sumoftwo_QNAME, Sumoftwo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnrollCourse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "enrollCourse")
    public JAXBElement<EnrollCourse> createEnrollCourse(EnrollCourse value) {
        return new JAXBElement<EnrollCourse>(_EnrollCourse_QNAME, EnrollCourse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveCourseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "removeCourseResponse")
    public JAXBElement<RemoveCourseResponse> createRemoveCourseResponse(RemoveCourseResponse value) {
        return new JAXBElement<RemoveCourseResponse>(_RemoveCourseResponse_QNAME, RemoveCourseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdvLogin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "advLogin")
    public JAXBElement<AdvLogin> createAdvLogin(AdvLogin value) {
        return new JAXBElement<AdvLogin>(_AdvLogin_QNAME, AdvLogin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdvLoginResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "advLoginResponse")
    public JAXBElement<AdvLoginResponse> createAdvLoginResponse(AdvLoginResponse value) {
        return new JAXBElement<AdvLoginResponse>(_AdvLoginResponse_QNAME, AdvLoginResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChangeCourseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://Server/", name = "changeCourseResponse")
    public JAXBElement<ChangeCourseResponse> createChangeCourseResponse(ChangeCourseResponse value) {
        return new JAXBElement<ChangeCourseResponse>(_ChangeCourseResponse_QNAME, ChangeCourseResponse.class, null, value);
    }

}
