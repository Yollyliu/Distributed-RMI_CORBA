package Message;

import java.net.DatagramPacket;
import java.util.ArrayList;
import java.util.HashMap;

public class FErequest extends Message {
    private static HashMap<RequestType,String> requestMap;
    private String department;
    private String requestID;
    private String functionName;
    private ArrayList<String> para;
    static {
        requestMap = new HashMap<>();
        requestMap.put(RequestType.Login,"Login");
        requestMap.put(RequestType.addCourse,"addCourse");
        requestMap.put(RequestType.removeCourse,"removeCourse");
        requestMap.put(RequestType.listCourseAvailability,"listCourseAvailability");
        requestMap.put(RequestType.enrolCourse,"enrolCourse");
        requestMap.put(RequestType.dropCourse,"dropCourse");
        requestMap.put(RequestType.getClassSchedule,"getClassSchedule");
        requestMap.put(RequestType.swapCourse,"swapCourse");
    }

    public FErequest(DatagramPacket packet) {
        super(packet.getAddress(),packet.getPort());
        String message = new String(packet.getData(),0,packet.getLength());
        getValueFromString(message);

    }
    public FErequest(String message) {
        getValueFromString(message);
    }

    private void getValueFromString(String message) {

        String parts[] = message.split("_");
        if(parts.length < 4)
            return;

        department = parts[0];
        requestID = parts[1];
        functionName = parts[2];
        para = new ArrayList<String>();
        for(int i = 3; i<parts.length; i++) {
            para.add(parts[i]);
        }
    }

    public FErequest(String campus_id,int requstNum, RequestType funcType, ArrayList<String> parameters){

        department = campus_id;

        requestID = "REQ" + String.valueOf(requstNum);

        functionName = requestMap.get(funcType);
        para = parameters;

    }


    public String paraToString(ArrayList<String> parameters) {

        String returnVal = "";
        for (int i = 0; i < parameters.size(); i++) {
            if(i == 0){
                returnVal += parameters.get(i);
            }else {
                returnVal = returnVal + "_" + parameters.get(i);
            }
        }
        return returnVal;

    }

    @Override
    public String pack() {

        String ret = department + "_" + requestID + "_" + functionName + "_" + paraToString(para);
//        System.out.println(ret);
        return ret;
    }

    public String getrequestID() {
        return requestID;
    }


}
