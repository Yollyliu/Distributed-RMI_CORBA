package Message;

import java.net.DatagramPacket;
import java.util.ArrayList;

public class MistakeToRM extends Message{

    private String ReplicaID;
    private String status;

    public MistakeToRM(String ReplicaID, String status) {

        this.ReplicaID = ReplicaID;
        this.status = status;

    }

    public MistakeToRM(DatagramPacket packet) {

        super(packet.getAddress(), packet.getPort());
        String message = new String(packet.getData(), 0, packet.getLength());
        getValueFromString(message);

    }

    public MistakeToRM(String message) {
        getValueFromString(message);
    }

    private void getValueFromString(String message) {

        String parts[] = message.split("_");
        if(parts.length < 2)
            return;

        ReplicaID = parts[0];
        status = parts[1];
    }

    @Override
    public String pack() {
        String ret = ReplicaID + "_" + status;
        return ret;
    }

//    public int getSeq_num() {
//        return seq_num;
//    }

    public String getReplicaID() {
        return ReplicaID;
    }

    public String getStatus() {
        return status;
    }

}
