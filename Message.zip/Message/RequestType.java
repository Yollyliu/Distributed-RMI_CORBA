package Message;

public enum RequestType {
    Login,
    addCourse,
    removeCourse,
    listCourseAvailability,
    enrolCourse,
    getClassSchedule,
    dropCourse,
    swapCourse
};
