package Message;

import java.net.InetAddress;

public abstract class Message {
    protected InetAddress srcIP;
    protected int srcPort;

    public Message() {
    }

    public Message(InetAddress srcIP, int srcPort) {
        this.srcIP = srcIP;
        this.srcPort = srcPort;
    }

    public abstract String pack();
}
