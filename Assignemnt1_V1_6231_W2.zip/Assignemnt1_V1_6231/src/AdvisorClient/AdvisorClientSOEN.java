package AdvisorClient;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import javax.xml.transform.Source;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

import SOEN.ServerInterface;

import java.io.InputStreamReader;
import java.util.LinkedList;

public class AdvisorClientSOEN {
	 public static void main(String args[]) throws Throwable{
			
			InputStreamReader is = new InputStreamReader(System.in);
	        BufferedReader br = new BufferedReader(is);
	        
	        System.out.println("Enter advisorD:");
	        Scanner Id = new Scanner(System.in);
	        String advID = Id.nextLine();
	        String campus = advID.substring(0,4);
	        String name = " ";
	        
	       
	        if(campus.equals("SOEN")){
	        	SOEN.ServerService serverService = new SOEN.ServerService();
	        	SOEN.ServerInterface serverInterface = serverService.getServerport();
				process(serverInterface,advID);
	        }  
	        else {
	       	 System.out.println("Invalid AdvID");
	       	 System.exit(0);
	        }
		}
		
		public static void process(ServerInterface serverInterface, String advID) throws Throwable{
			
			if(serverInterface.advLogin(advID)){
		        System.out.println("Log in successfully");
		        LOG(advID, GetDate() + " " + advID + " log in successfully");
			}
		    else{
		    	System.out.println("Log in Unsuccessfully");
		    	LOG(advID, GetDate() + " " + advID + " log in failed");
		    }
			
			 while(true){
				 while(true){
		        	 System.out.println(" ");
		        	 System.out.println("Please select an operation: ");
		        	 System.out.println("1: add Course");
		        	 System.out.println("2: remove Course");
		        	 System.out.println("3: list Course Availibility");
		        	 System.out.println("4: enroll Course");
		        	 System.out.println("5: get class Schedule");
		        	 System.out.println("6: drop course");
		        	 System.out.println("7: change course");
		        	 System.out.println("8: Exit" + "\n");
		        	 Scanner s = new Scanner(System.in);
			         int input = s.nextInt();
		        	 switch (input) {
		        	 case 1:
		        		 A(advID,serverInterface);
		        		 
		        		 break;
		        	 case 2:
		        		 R(advID,serverInterface);
		        		 
		        		 break;
		         case 3:
			        	 LA(advID,serverInterface);
			        	 
			        	 break;
			     case 4:
			        	 EC(advID,serverInterface);
			        	 
			        	 
			        	 break;
			   	 case 5:
		        		GCS(advID,serverInterface);
		        		
		        		break;
		        	 case 6:
		        		 
		        		 DC(advID,serverInterface);
		        		 break;
		         case 7:
			        	 CC(advID,serverInterface);
			        	 
			        	 
			        	 break;

		        	 case 8:
		        		 System.exit(0);
					default:
						break;
		        	 
				 }
	   
			}
	      	 
	         }
		}


	    public static void LOG(String ID,String Message) throws Exception{
			
			String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/ClientLog/" + ID + ".txt";     
			FileWriter fileWriter = new FileWriter(path,true);
			BufferedWriter bf = new BufferedWriter(fileWriter);
			bf.write(Message + "\n");
			bf.close();
		}
		
		public static String GetDate(){
			
		    Date date = new Date();
		    long times = date.getTime();
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    String dateString = formatter.format(date);
		    return dateString;
		}
		
		public static boolean IsInteger(String s) {
			
		    return IsInteger(s,10);
		}

		public static boolean IsInteger(String s, int radix) {
			
		    if(s.isEmpty()) return false;
		    for(int i = 0; i < s.length(); i++) {
		        if(i == 0 && s.charAt(i) == '-') {
		            if(s.length() == 1) return false;
		            else continue;
		        }
		        if(Character.digit(s.charAt(i),radix) < 0) return false;
		    }
		    return true;
		}
		
		public static boolean IsStudent(String studentID) {
			
			String curDepart=studentID.substring(0, 4);
			String lastFour=studentID.substring(5);
	        
	        if( studentID.charAt(4)=='S' && lastFour.length()==4 && IsInteger(lastFour)) {
//		         if(curDepart.equals("COMP") ||curDepart.equals("INSE")||curDepart.equals("SOEN") ) {
		         if(curDepart.equals("SOEN") ) {

		        	      return true;
		        	 }
		         return false;
	        }
	       return false;
			
		}
		
		public static boolean IsCourse(String courseID){
			
			String dept=courseID.substring(0,4);
			String numid=courseID.substring(4);
			if(dept.equals("COMP") ||dept.equals("INSE") || dept.equals("SOEN")){

//			if(dept.equals("SOEN") ){
				if(IsInteger(numid)){
					return true;
				}
			}
			return false;
		}
		
		

	        
	        

		
		public static void A(String advID, ServerInterface serverInterface) throws Throwable {
			System.out.println("Enter courseID");
			Scanner input = new Scanner(System.in);
			String courseID = input.nextLine();
			System.out.println("Enter term");
			String term = input.nextLine();
			System.out.println("Enter capacity");
			String capacity = input.nextLine();
			
			if(IsCourse(courseID)) {
				if(serverInterface.addCourse(courseID, term, advID, capacity)) {	
					System.out.println("add course successfully!");
					LOG(advID, GetDate() + " " + advID + " add course successfully. " 
							+ "Course information: " + term + " " + capacity + " " );
				}
				else{
					System.out.println("add course failed!"); 
					LOG(advID, GetDate() + " " + advID + " add course failed");

				}
			}else {
				System.out.println("Invalid courseID");
			}
			} 
		
		public static void R(String advID, ServerInterface serverInterface) throws Throwable{
			System.out.println("please enter courseID");
			Scanner input = new Scanner(System.in);
			String courseID = input.nextLine();
			System.out.println("enter term");
			String term = input.nextLine();
			
			if(IsCourse(courseID)) {
				if(serverInterface.removeCourse(courseID,term,advID)){
					System.out.println("Remove a course successfully!");
					LOG(advID, GetDate() + " " + advID + " remove a course successfully. " 
						 + "course information: " + courseID + " " + term );
				}
				else{
					System.out.println("Remove a course Unsuccessfully!");
					LOG(advID, GetDate() + " " + advID + " fail to remove a course");
				}
			}else {
				System.out.println("Invalid CourseID");
			}
			
		}
		
		
		public static void LA(String advID, ServerInterface serverInterface) throws Throwable {
			System.out.println("Enter term");
			Scanner input = new Scanner(System.in);
			String term = input.nextLine();
		
			String result=serverInterface.listCourseA(advID, term);
			System.out.println(result);
		
		  LOG(advID, GetDate() + " " + advID + " check term successful : "+ result);
			
		}
		public static void EC(String advisorID, ServerInterface serverInterface) throws Throwable{
			System.out.println("Enter studentID");
			Scanner input = new Scanner(System.in);
			String sID = input.nextLine();
			System.out.println("Enter term");
			String termT = input.nextLine();
			System.out.println("Enter courseID");
			String courID = input.nextLine();
//			String result=crImpl.enrollCourse(sID, courID, termT);
			
			if(IsStudent(sID) && IsCourse(courID) && sID.substring(0, 4).equals(advisorID.substring(0, 4)) ) {
				String result=serverInterface.enrollCourse(sID,courID, termT);
//				System.out.println("The student : "+sID+" The course is : "+ courID+" the term is : "+ termT);
	   		 if(result.contains("succes")){
	   			 System.out.println("Student "+sID+" successfully enrolled in course "+ courID);
	   			 LOG(advisorID,  GetDate() + " Adivisor: "+advisorID +" successfully let Student: " + sID + " to enrolled in course " + courID
		        			 +" in term "+ termT);
	   			 LOG(sID,  GetDate() + " Student: " + sID + " successfully enrolled in course " + courID+ " by advisor :"+ advisorID
		        			 +" in term "+ termT);
	   		 }
	   		 else {
	   			 System.out.println("Student "+ sID+ " failed to enroll in course "+ courID);
	   			 LOG(advisorID, GetDate() +" Adivisor: "+advisorID +" fail to let Student: " + sID + "  enroll in course " + courID
		        			 +" in term "+ termT);
	   			 LOG(sID,  GetDate() + " Student: " + sID + " fail to enrolled in course " + courID+ " by advisor :"+ advisorID
		        			 +" in term "+ termT);
	   		 }
	   		 }else {
	   			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	   			 
	   		 }
				
		
		}
		
		
		public static void DC(String advisorID, ServerInterface serverInterface) throws Throwable {
			System.out.println("Enter studentID");
			Scanner input = new Scanner(System.in);
			String stdID6 = input.nextLine();
			System.out.println("Enter courseID");
			String cID6 = input.nextLine();
			
			
			if(IsStudent(stdID6)&& stdID6.substring(0, 4).equals(advisorID.substring(0, 4))) {
	   		 if(serverInterface.dropCourse(stdID6, cID6)){
	   			 System.out.println("Student "+stdID6+" successfully drop course "+ cID6);
	   			 LOG(advisorID,  GetDate() + " Advisor: "+advisorID+" successfuly let student " + stdID6 + " to drop course " + cID6);
	   			 LOG(stdID6,  GetDate() + " Student " + stdID6 + " successfully drop course " + cID6 +" by advisor: "+advisorID);
		        			 
	   		 }
	   		 else {
	   			 System.out.println("Student "+ stdID6+ " failed to drop  course "+ cID6);
	   			 LOG(advisorID, GetDate() + " Advisor: "+advisorID + " fail to let "+ stdID6 + " to drop in course " + cID6);
	   			 LOG(stdID6, GetDate() + " Student " + stdID6 + " failed to drop in course " + cID6+ " by advisor:"+advisorID);
		        			
	   		 }
	   		 }else {
	   			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	   		 }
			 
		}
		public static void GCS(String advisorID, ServerInterface serverInterface) throws Throwable{
			System.out.println("Enter studentID");
			Scanner input = new Scanner(System.in);
			String stdID5 = input.nextLine();
			String result=serverInterface.getClassSchedule(stdID5);
			
			
			 if(IsStudent(stdID5)&&(stdID5.substring(0, 4).equals(advisorID.substring(0, 4)))) {
			String result5=serverInterface.getClassSchedule(stdID5);
	    		 System.out.println( stdID5+ "course schedule: "+ result5);
				 LOG(advisorID, GetDate() + " Advisor: "+advisorID+" got student " + stdID5 + " course schedule: " + result5);
				 LOG(stdID5, GetDate() + " Student " + stdID5 + " course schedule: " + result5+ " got by advisor: "+advisorID);
	    		 }else {
	    			 System.out.println("Invalid StudentID or Advisor and Student belongs to different department");
	    		 }

		}
		
		
		public static void CC(String advisorID, ServerInterface serverInterface) throws Throwable {
			System.out.println("Enter studentID");
			Scanner input = new Scanner(System.in);
			String stdID = input.nextLine();
			System.out.println("Enter oldID");
			String oldID = input.nextLine();
			System.out.println("Enter newID");
			String newID = input.nextLine();
			
			if(IsStudent(stdID)&& IsCourse(newID) && IsCourse(oldID) &&(stdID.substring(0, 4).equals(advisorID.substring(0, 4)))) {
//				 System.out.println("The student : "+stdID+" change the course is : "+ oldID+" to new course term is : "+ newID);
				 String ans=serverInterface.changeCourse(stdID,oldID,newID);
				 System.out.println(ans);
				 if(ans.contains("success")){

					 System.out.println("Student "+stdID+" successfully change course "+ oldID+" to new course "+newID);
					 LOG(advisorID,  GetDate() + " Adivisor: "+advisorID +" successfully let Student: "
							 + stdID+" successfully change course "+ oldID+" to new course "+newID);
					 LOG(stdID,  GetDate() + " Student: " + stdID+
							 " successfully change course "+ oldID+" to new course "+newID);
				 }
				 else {
					 System.out.println("Student "+ stdID+ " failed to change course "+ oldID+" to new course term is : "+ newID);
					 LOG(advisorID, GetDate() +" Adivisor: "+advisorID +" fail to let Student: "+ stdID+
							 "  change course "+ oldID+" to new course term is : "+ newID);
					 LOG(stdID,  GetDate() + " Student: " +stdID+
							 " failed to change course "+ oldID+" to new course term is : "+ newID);
				 }
			 }else {
				 System.out.println("Invalid StudentID or courseID");

			 }
			
		
		}
	
	
	

}
