package AdvisorClient;

public class Test {
public static void main(String[] args) {
		
		COMP.ServerService serverService = new COMP.ServerService();
		COMP.ServerInterface serverInterface = serverService.getServerport();
		System.out.println(serverInterface.sumoftwo(5, 10));
	}

}
