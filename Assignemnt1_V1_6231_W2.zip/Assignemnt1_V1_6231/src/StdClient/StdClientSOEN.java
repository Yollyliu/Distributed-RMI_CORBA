package StdClient;

import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import SOEN.ServerInterface;

import java.io.InputStreamReader;

public class StdClientSOEN {

	
    public static void Log(String ID,String Message) throws Exception{
		
		String path = "/Users/youlin-liu/eclipse-workspace/Assignemnt1_V1_6231/ClientLog/" +ID + ".txt";   //no pathing at this time
		FileWriter fileWriter = new FileWriter(path,true);
		BufferedWriter bf = new BufferedWriter(fileWriter);
		bf.write(Message + "\n");
		bf.close();
	}


	public static String getDate(){
	    Date date = new Date();
	    long times = date.getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String dateString = formatter.format(date);
	    return dateString;
	}
	
	public static boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
	
	public static boolean isStudent(String studentID) {
		String curDepart=studentID.substring(0, 4);
		String lastFour=studentID.substring(5);

		if( studentID.charAt(4)=='S' && lastFour.length()==4 && isInteger(lastFour)) {
//			if(curDepart.equals("COMP") ||curDepart.equals("INSE")||curDepart.equals("SOEN") ) {

			if(curDepart.equals("SOEN") ) {
				return true;
			}
			return false;
		}
		return false;

	}
	
	public static boolean isCourse(String courseID){
		String dept=courseID.substring(0,4);
		String numid=courseID.substring(4);

		if(dept.equals("COMP") ||dept.equals("INSE") || dept.equals("SOEN")){
			if(isInteger(numid)){
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) throws Throwable {
		
		 System.out.println("Enter studentID:");
	        Scanner Id = new Scanner(System.in);
	        String studentID = Id.nextLine();
	        String department = studentID.substring(0,4);
	        String name = " ";
	        
	        if(department.equals("SOEN")){
	        	SOEN.ServerService serverService = new SOEN.ServerService();
				SOEN.ServerInterface serverInterface = serverService.getServerport();
				process(serverInterface, studentID);
	        }
	        else {
	       	 System.out.println("Invalid StudentID");
	       	 System.exit(0);
	        }
	}
	
	public static void process(ServerInterface serverInterface, String studentID) throws Throwable{
		if(serverInterface.stdLogin(studentID)){
	        System.out.println("Log in successfully");
	        Log(studentID, getDate() + " " + studentID + " log in successfully");
		}
	    else{
	    	System.out.println("Log in Unsuccessfully");
	    	Log(studentID, getDate() + " " + studentID + " log in failed");
	    }
	       
				
				while(true){
			       	 System.out.println(" ");
			       	 System.out.println("Please select an operation: ");
			       	 System.out.println("1: enroll course");
			       	 System.out.println("2: drop course");
			       	 System.out.println("3: get course schedule");
			       	 System.out.println("4: change course");
			       	 System.out.println("5: Exit" + "\n");
			       	 
			       	 Scanner s = new Scanner(System.in);
				     int input = s.nextInt();
			       	 switch (input) {
			       	 case 1:
			       		 EC(studentID,serverInterface);
			       		 
			       		 break;
			       	 case 2:
			       		 DC(studentID,serverInterface);
			       		 
			       		 break;
			       	 case 3:
			       		 GCS(studentID,serverInterface);
			       		 
			       		 break;
			       	 case 4:
			       	     CC(studentID,serverInterface);
			       	     
			       		 break;
			       	 case 5:
			       		 System.exit(0);
						default:
							break;
						}     	 
			        }
			

	}
	

	
	public static void GCS(String studentID,ServerInterface serverInterface) throws Throwable{
  		String string = serverInterface.getClassSchedule(studentID);
  		System.out.println(string);      
  		Log(studentID, getDate() + " " + studentID + " class schedule is " + string);
	}
	
	public static void EC(String studentID, ServerInterface serverInterface) throws Throwable{
		System.out.println("Enter the courseID");
  		Scanner input = new Scanner(System.in);     		 
  		String courseID = input.nextLine();
  		System.out.println("Enter the term");  		 
  		String term = input.nextLine();
  		
  		String result = serverInterface.enrollCourse(studentID, courseID, term);
  		System.out.println(result);
  		if(result.contains("fai")){
  			
  			Log(studentID, getDate() + " " + studentID + " fail to enroll in "+courseID);
  		}
  		else {
  			
  			
  			Log(studentID, getDate() + " " + studentID + " successfully to enroll in " + courseID);
  		}
	}
	
	public static void DC(String studentID, ServerInterface serverInterface) throws Throwable{
		System.out.println("Enter courseID");
		Scanner input = new Scanner(System.in);     		 
 		String courseID = input.nextLine();
 		if(serverInterface.dropCourse(studentID, courseID)){
 			System.out.println("Drop course Successfully");
 			Log(studentID, getDate() + " " + studentID + " successfully drop " + courseID);
 			
 		}
 		else {
 			System.out.println("Drop course failed");
 			Log(studentID, getDate() + " " + studentID + " failed to drop course "+ courseID);
 		 }
	}
	
	public static void CC(String studentID,ServerInterface serverInterface) throws Throwable{
		 System.out.println("Enter old courseID");
   		 Scanner input = new Scanner(System.in);     		 
   		 String oldID = input.nextLine();
   		 System.out.println("Enter new courseID");
   		 String newID = input.nextLine();
   		 
   		 
   		 if(isStudent(studentID)&& isCourse(newID) && isCourse(oldID)) {
			 System.out.println("The student : "+studentID+" change the course is : "+ oldID+" to new course term is : "+ newID);
			 String ans=serverInterface.changeCourse(studentID,oldID,newID);
			 System.out.println(ans);
			 if(ans.contains("succe")){
				 System.out.println("Student "+studentID+" successfully change course "+ oldID+" to new course "+newID);

				 Log(studentID,  getDate() + " Student: " + studentID+
						 " successfully change course "+ oldID+" to new course "+newID);
			 }
			 else {
				 System.out.println("Student "+ studentID+ " failed to change course "+ oldID+" to new course term is : "+ newID);

				 Log(studentID,  getDate() + " Student: " +studentID+
						 " failed to change course "+ oldID+" to new course term is : "+ newID);
			 }
		 }else {
			 System.out.println("Invalid StudentID or courseID");

		 }


//   		 String newbookingID = crImpl.changeCourse(studentID,oldID,newID);
//   		 if(newbookingID.contains("fa")){
//   			System.out.println("class change failed");
//   			Log(studentID, getDate() + " " + studentID + " course change failed");
//   		 }
//   		 else{
//   			System.out.println("change course successfully. " );
//   			Log(studentID, getDate() + " " + studentID + " change course successfully. " );
//   			
//   		 }
	}

}
