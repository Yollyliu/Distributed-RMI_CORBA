package Server;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;


@WebService

public interface ServerInterface  {
	
	@WebMethod
	int sumoftwo(int x,int y);
	@WebMethod
	public boolean advLogin(String advID);
	@WebMethod
	public boolean stdLogin(String stdID) ;

	
//	public boolean addCourse(String courseID, String term, String advID, LinkedList<String> courseDetail) ;
	@WebMethod
	public boolean addCourse(String courseID, String term, String advID, String capacity);
	@WebMethod
	public boolean removeCourse(String courseID,String term, String advID);
	@WebMethod
	public String listCourseA(String advID,String term);
	@WebMethod
	public String enrollCourse(String studID,String courseID, String term);
	@WebMethod
	public boolean dropCourse(String studID, String courseID);
	@WebMethod
	public String getClassSchedule(String studID) ;
	@WebMethod
	public String changeCourse(String stdID, String oldID, String newID);
	
	

}
