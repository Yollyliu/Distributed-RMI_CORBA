package Server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

import javax.xml.ws.Endpoint;



public class Publish {

	public static void main(String[] args) throws Exception {
		
		
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		int udpportnum = 0;
		String department = " ";
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Department: ");
		department = s.nextLine();
		String name = " ";
		String startport = " ";
		
		if(department.equals("COMP")){
			startport = "1111";
    		name = "DCRSCOMP";
    		udpportnum = 2111;
    	}
    	else if(department.equals("INSE")){
    		startport = "2222";
    		name = "DCRSINSE";
    		udpportnum = 3222;
    	}
    		
    	else if(department.equals("SOEN")){
    		startport = "3333";
    		name = "DCRSSOEN";
    		udpportnum = 4333;
    	}
    	else{
    		System.out.println("Server started failed");
			System.exit(0);
    	}
		CRImpl crImplImp = new CRImpl();
		DatagramSocket serversocket = new DatagramSocket(udpportnum);
	    startlistening(department, crImplImp, udpportnum, serversocket);
	    crImplImp.StartServer(department);
		
	    String url = "http://localhost:" + startport + "/" + name;
	    System.out.println(url);
		Endpoint endpoint = Endpoint.publish("http://localhost:" + startport + "/" + name, crImplImp);
		System.out.println("localhost:" + startport + "/" + name);
		System.out.println(endpoint.isPublished());
	}
	
	private static void startlistening(String campusName, CRImpl campusSever, int UDPlistenPort, DatagramSocket SeverSocket) throws Exception {
		
		String threadName = campusName + "listen";
		Listening listen = new Listening(threadName, SeverSocket, campusSever);
		listen.start();
	}

}
